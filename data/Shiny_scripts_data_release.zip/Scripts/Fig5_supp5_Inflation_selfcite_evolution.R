###
### The Strain on Scientific Publishing - Fig5_supp5_Inflation_selfcite_evolution.R
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description: 
### Generates figure 5supp5 -- evolution of impact inflation and self-citation rates
###
###
###

## evol inflation

df_filtered <- df %>% 
  filter(year == 2016 | year == 2022) %>% 
  filter(publisher %in% subset_publishers) %>%
  mutate(year = as.factor(year)) %>% 
  mutate(inflation = cit_per_doc_2 / SJR) %>% 
  group_by(year, publisher) %>% 
  summarise(meaninf = mean(inflation, na.rm = TRUE), .groups = "drop") %>% 
  group_by(publisher) %>% 
  arrange(publisher, year) %>% 
  mutate(meaninf21 = if_else(year == "2022", meaninf, last(meaninf))) %>% 
  mutate(signchange = last(meaninf) > first(meaninf), 
         point_type = case_when(
           year == "2016" & signchange ~ "\u26AB", 
           year == "2016" & !signchange ~ "\u25C0",
           year == "2022" & signchange ~ "\u25B6",
           year == "2022" & !signchange ~ "\u26AB"
         )) 

## impact inflation ggplot

time_comparison_colors <- c("#377EB8", "#4DAF4A")

Fig5_supp5A<-ggplot(df_filtered, aes(meaninf, reorder(publisher, meaninf21))) +
  geom_line(aes(group = publisher), color = "gray90", linewidth = 3) +
  geom_point(aes(color = year, shape = year), size = 5) +
  scale_color_manual(values = c("#377EB8", "#4DAF4A")) +
  scale_shape_manual(values = c(16, 16)) +
  labs(
    title = "Evolution of Impact Factor inflation: <span style = 'color: #377EB8;'>2016</span> to <span style = 'color: #4DAF4A;'>2022</span>", 
    x = "IF inflation (Cites at 2 years over SJR)",
    y = "", 
    caption = "Source: Scimago website data"
  ) +
  theme(panel.grid.major.y = element_line(linetype = "dotted"), 
        plot.title = element_markdown(),
        legend.position = "none",
        panel.grid.minor.y = element_blank(),
        plot.title.position = "plot",
        axis.text.y = element_text(hjust = 0.5, size=16), 
        axis.title.y = element_text(size = 18),
        axis.title.x = element_text(size = 18),
        axis.text.x = element_text(size = 16), 
        legend.text = element_text(size = 14),
        legend.title = element_text(size = 14))
Fig5_supp5A
ggsave(plot=Fig5_supp5A,"Figures/Building blocks/Fig5_supp6a_evol_Inflation.png",
       height = 9/1.1, width = 12/1.1, units = "in", dpi = 300)


## evol self-cite

Fig5_supp5B<-df_sc %>% 
  filter(year == 2016 | year == 2022 & total_cites > 1000) %>%
  filter(share_self_cite < 0.25) %>%# same visual filters as applied previously. A few extreme share_self_cite outliers greatly increase the mean visualized, and these are not censored in the statistics. However for data visualization, they have been removed as, for instance, Taylor and Francis has a couple journals with share_self_cites > 0.4, and Springer > 0.6. These skew the data visualization unfairly, which is why medians from boxplots within violin plots are useful as central tendency.
  filter(publisher %in% subset_publishers) %>%
  mutate(year = as.factor(year)) %>% 
  mutate(selfcites = self_cites) %>% 
  group_by(year, publisher) %>% 
  summarise(mean_selfcites = mean(share_self_cite, na.rm = T)) %>% 
  group_by(publisher) %>% 
  arrange(publisher, year) %>% 
  mutate(mean_selfcites22 = if_else(year == 2022, mean_selfcites, last(mean_selfcites))) %>% 
  mutate(signchange = last(mean_selfcites) > first(mean_selfcites), 
         point_type = case_when(year == "2016" & signchange == "TRUE" ~ "\u26AB", 
                                year == "2016" & signchange == "FALSE" ~ "\u26AB",
                                year == "2022" & signchange == "TRUE" ~ "\u25B6",
                                year == "2022" & signchange == "FALSE" ~ "\u25C0")) %>% 

  ggplot(aes(mean_selfcites, reorder(publisher,mean_selfcites22)))+
  geom_line(aes(group = publisher), color = "gray90", linewidth = 3) +
  geom_point(aes(color = year, shape = year), size = 5) +
  scale_color_manual(name = "", values = c("#377EB8", "#4DAF4A"))+
  scale_shape_manual(values = c(16, 16)) +
  labs(title = "Evolution of within-journal self-citation rate: <span style = 'color: #377EB8;'>2016</span> to <span style = 'color: #4DAF4A;'>2022</span>", 
       y = "",
       x = "Proportion self-citation", 
       caption = "Journals with total annual citations > 1000 and below 0.25 in 2022, avoids skewed view of central tendency caused by major outliers
       (no maximum self-cite rate was censored in statistical analysis)
       Source: Scimago scrape data")  +
  theme(panel.grid.major.y = element_line(linetype = "dotted"), 
        plot.title = element_markdown(),
        legend.position = "none",
        panel.grid.minor.y = element_blank(),
        plot.title.position = "plot",
        axis.text.y = element_text(hjust = 0.5, size=16), 
        axis.title.y = element_text(size = 18),
        axis.title.x = element_text(size = 18),
        axis.text.x = element_text(size = 16), 
        legend.text = element_text(size = 14),
        legend.title = element_text(size = 14))
Fig5_supp5B

ggsave(plot=Fig5_supp5B,"Figures/Building blocks/Fig5_supp6b_evol_selfcite.png",
       height = 9/1.1, width = 12/1.1, units = "in", dpi = 300)


# Figure 5_supp5
Figure5_supp5 <- (Fig5_supp5A / Fig5_supp5B)
Figure5_supp5 + plot_annotation(tag_levels = 'A') &
  theme(plot.tag = element_text(size = 36))
ggsave("Figures/Supplemental/Fig5_supp5_dumbell_plots.png", 
       width = 15, height = 20, units = "in", dpi = "retina")
