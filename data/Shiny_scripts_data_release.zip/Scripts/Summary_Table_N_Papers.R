###
### The Strain on Scientific Publishing 
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description:
### Save the N papers in 2013 and 2022 as well as the rate of change thereof for the final table
###
###

## N papers in 2016 & 2022
overall_N <- df %>% 
  filter(year == 2016 | year == 2022) %>% 
  group_by(year) %>% 
  summarise(N = sum(Ndocs))

final_table_N_overall <- overall_N %>% 
  mutate(publisher = "Overall") %>% 
  pivot_wider(names_from = year, values_from = N, names_prefix = "N_")



## N papers in 2016 & 2022, by publisher
publisher_N <- df %>% 
  filter(publisher %in% main_publishers) %>% 
  filter(year == 2016 | year == 2022) %>% 
  group_by(year, publisher) %>% 
  summarise(N = sum(Ndocs))

final_table_N_publisher <- publisher_N %>% 
  group_by(publisher) %>% 
  pivot_wider(names_from = year, values_from = N, names_prefix = "N_")


## saving for the final table
summary_table_N <- bind_rows(final_table_N_overall, final_table_N_publisher) %>% 
  arrange(-N_2022) %>% 
  mutate(publisher = if_else(publisher == "PLoS", "PLOS", publisher))

## cleaning up
rm(overall_N, final_table_N_overall, publisher_N, final_table_N_publisher)
