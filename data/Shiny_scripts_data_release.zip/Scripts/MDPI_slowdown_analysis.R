###
### The Strain on Scientific Publishing - MDPI_slowdown_analysis.R
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description: 
### Produces Table1 supp 1: monthly change in submitted papers at MDPI since beginning 2022
### 
###


## getting the data

df <- read_csv("Data/monthly_MDPI_data_August_23.csv")

## first, let's clean all the NAs -- missing data
df <- df %>% 
  filter(!is.na(value)) %>% 
  select(journal, year, month, indicator, value) %>% 
  pivot_wider(names_from = indicator, values_from = value) %>% 
  mutate(rejection_rate = rejected / (accepted + rejected)) %>% 
  mutate(date = lubridate::ym(paste(year, month)), 
         month = lubridate::month(date)) %>% 
  mutate(submitted = accepted + rejected)


## ok, now, let's look at data from 2020 to today
recent <- df %>% 
  filter(year >= 2020)




## function to generate the tabel

gen_table <- function(df, var, varch, topn){
  top25df <- df %>% 
    group_by(journal, year) %>% 
    summarise(n = sum(accepted)) %>% 
    filter(year == 2022) %>% 
    arrange(-n) %>% 
    select(-year)
  
  top25df2023 <- df %>% 
    group_by(journal, year) %>% 
    summarise(n = sum(accepted)) %>% 
    filter(year == 2023) %>% 
    arrange(-n) %>% 
    select(-year)
  
  top25 <- top25df %>% 
    head(topn) %>% 
    pull(journal)
  
  growth <- df %>% 
    filter(date >= ymd("20211201")) %>% 
    filter(journal %in% top25) %>% 
    group_by(journal) %>% 
    mutate(growth = ({{var}}-lag({{var}}))/lag({{var}}))
  
  bign <- df %>% 
    group_by(year) %>% 
    summarise(n = sum(accepted)) %>% 
    filter(year==2022) %>% 
    pull(n)
  
  growth_overall <- df %>% 
    filter(date >= ymd("20211201")) %>% 
    filter(journal %in% top25) %>% 
    group_by(date) %>% 
    summarise(sum = sum({{var}})) %>% 
    mutate(journal = "Overall") %>% 
    select(journal, date, sum) %>% 
    mutate(sum = (sum-lag(sum))/lag(sum)) %>% 
    mutate(sum = round(100*sum,2)) %>% 
    filter(date > ymd("20211201")) %>% 
    ungroup() %>% 
    pivot_wider(names_from = date, values_from = sum) %>% 
    mutate(n = bign) %>% 
    select(journal, n, everything())
    
  
  monthly_n <- df %>% 
    filter(date >= ymd("20220101")) %>% 
    group_by(year, month) %>% 
    summarise(N = sum(accepted))
  
  monthly_n_peak_jou <- df %>% 
    filter(date >= ymd("20220101")) %>% 
    group_by(year, month, journal) %>% 
    summarise(N = sum(accepted)) %>% 
    group_by(journal) %>% 
    filter(N == max(N)) %>% 
    select(journal, `Max monthly N at peak` = N) %>% 
    distinct()
  
  july23_n_jou  <- df %>% 
    filter(date == ymd("20230701")) %>% 
    select(journal, `monthly N july 23` = accepted)
  
  monthly_data <- july23_n_jou %>% 
    left_join(monthly_n_peak_jou, by = "journal") %>% 
    arrange(-`Max monthly N at peak`) %>% 
    mutate(change = (`monthly N july 23`-`Max monthly N at peak`)/`Max monthly N at peak`) %>% 
    rename(Npeak = `Max monthly N at peak`, 
           Njuly = `monthly N july 23`)
  
  monthly_data <- monthly_data %>% 
    summarise(Npeak = sum(Npeak), 
              Njuly = sum(Njuly)) %>% 
    mutate(journal = "Overall",
           change = (Njuly - Npeak)/Npeak) %>% 
    bind_rows(monthly_data)
  
  growth_table <- growth %>% 
    filter(date > ymd("20211201")) %>% 
    left_join(top25df) %>% 
    select(journal, n, date, growth) %>% 
    mutate(growth = round(100*growth,2)) %>% 
    pivot_wider(names_from = date, values_from = growth) %>% 
    arrange(-n) %>% 
    ungroup()
  
  min = 100*min(growth$growth, na.rm = T)-1
  max = 100*max(growth$growth, na.rm = T)+1
  
  growth_overall %>% 
    bind_rows(growth_table) %>% 
    rename(`N 2022` = n, jan = `2022-01-01`, feb = `2022-02-01`, mar = `2022-03-01`,
           apr = `2022-04-01`, may = `2022-05-01`, jun = `2022-06-01`,
           jul = `2022-07-01`, aug = `2022-08-01`, sep = `2022-09-01`,
           oct = `2022-10-01`, nov = `2022-11-01`, dec = `2022-12-01`,
           JAN = `2023-01-01`, FEB = `2023-02-01`, MAR = `2023-03-01`,
           APR = `2023-04-01`, MAY = `2023-05-01`, JUN = `2023-06-01`, 
           JUL = `2023-07-01`, AUG = `2023-08-01`)%>% 
    gt() %>% 
    gt_theme_538() %>% 
    cols_align(align = "center", columns = -journal) %>% 
    tab_spanner(label = "2022", columns = 3:14) %>% 
    tab_spanner(label = "2023", columns = 15:22) %>% 
    data_color(
      columns = 3:22,
      method = "bin",
      palette = c("red", "grey", "green"), 
      bin = c(min,-25, -12.5,-5, 0,5, 12.5, 25, max)
    ) %>% 
    cols_align(align = "center", columns = -journal) %>% 
    tab_style(style = cell_borders(sides = c("top","bottom"), weight = px(2)), 
              locations = cells_body(rows = journal == "Overall", columns = 3:19)) %>% 
    tab_header(title = md(paste0("Monthly % change in **", 
                              varch, 
                              "** papers -- ", 
                              topn, 
                              " largest MDPI journals ")), 
               subtitle = "Overall = 98 journals with an Impact Factor as of February 2023 and detailed for the 25 largest MDPI journals") %>% 
    tab_source_note(source_note =  "Source: data scraped on the publisher's website") %>% 
    tab_style(style = cell_text(align = "right"),locations = cells_source_notes())
}  




gen_table(df, submitted, "submitted", 25) %>% 
  gtsave("Tables/Table1supp1.htm")
webshot2::webshot(url = "Tables/Table1supp1.htm", file = "Tables/Table1supp1.png", 
                  vwidth = 1500, vheight = 1200, zoom = 4)


