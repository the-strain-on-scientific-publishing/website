###
### The Strain on Scientific Publishing - cleanup_after_part_2.R
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description:
### To reduce memory footprint & speed up R, delete objects that will not be needed from now on
###
###


## datasets
rm(SIdata, TAT, TATdata, TATevo)

## cleanup
gc()
