###
### The Strain on Scientific Publishing - cleanup_after_part_4.R
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description:
### To reduce memory footprint & speed up R, delete objects that will not be needed from now on
###
###

## figures
rm(bot_plot, top_plot)
rm(Fig4A,Fig4B,Fig4_patchwork, graph1, graph2,graph3,graph4)


## datasets
rm(data_frames, df_elsev, df_front, df_mdpi, df_plos, PGB_2022_Rejection_rates, 
   RRdf, RRmerged_df)
rm(df, df_hind)

## glm models and data
rm(Elsevier_Models_under_2delta, Elsevier_RR, Hindawi_Models_under_2delta, Hindawi_RR,
   MDPI_Models_under_2delta, MDPI_RR, Tukey_plot_table, Tukey, 
   Taylor_Models_under_2delta, Taylor_RR, TaylorFrancis_RR)
rm(model, RR_aov, to_dredge)

## various
rm(jitterer)
rm(axis_title,corr)

## vectors
rm(jou2016, na_rows, pub_colors_TATs)

## cleanup
gc()


# Mark added here because the publisher colour mapping got messed up because plots in Fig3/4 are sorting publishers alphabetically and weren't coded to accept the get_publisher_color vector

publisher_comparison_colors <- c("#c86434", "#4bafd0", "#cd555d", "#79b543", "#b05cc6", "#55af7d", "#c55d93", "#6a7732", "#7178ca", "#c79e48") # palette of 10 colours by iwanthue intended to be as visually distinct for colour blind folks as possible

# making this for later when we want to call all publisher colours consistently across figures
list_main_publishers <- c("Elsevier", "MDPI", "Springer", "Wiley", "Frontiers", "Taylor & Francis", "Hindawi", "PLOS", "BMC", "Nature") # formerly Wiley-Blackwell


# A function to match colours to publishers consistently throughout
get_publisher_color <- function(publisher_name) {
  if (publisher_name %in% list_main_publishers) {
    idx <- match(publisher_name, list_main_publishers)
    publisher_comparison_colors[idx]
  } else {
    "grey"  # Default color for publishers not in the list_main_publishers
  }
}
publisher_color_mapping <- setNames(publisher_comparison_colors, list_main_publishers)
