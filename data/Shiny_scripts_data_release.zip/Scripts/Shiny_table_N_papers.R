## here we create a table that we will use to feed a shiny app
##
## see the relevant documentation in the shiny app scripts
##
## but basically
##
## - for each publisher
## - for each journal
##    . we collect a set of data
##
## Here:
##    - SJR
##    - IF (Cit_per_doc_2)
##    - Cit_per_doc_3 to be used for ShinyApp Imp Inf calculation
##    - N papers per year, 2016/22

colnames(df)

## get data
shiny_tab_N <- df %>% 
  select(title, issn, publisher, year, Ndocs, SJR, cit_per_doc_2, cit_per_doc_3) %>% 
  filter(year >= 2016 & year <= 2022) %>% 
  arrange(title, year)

## save data to right place

shiny_tab_N %>% 
  write_csv("Shiny_app/Data/shiny_tab_N_IF_SJR.csv")
