###
### The Strain on Scientific Publishing - Fig1_N_papers_per_Publisher.R
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description:
### generates figure 1B -- N papers per publishers across the years
###
###

##### 1. Data cleaning #####

## Vector of the main publishers
main_publishers <- c("MDPI",
                     "Nature",
                     "Springer",
                     "Elsevier",
                     "Frontiers",
                     "Wiley",
                     "PLOS",
                     "BMC",
                     "Hindawi",
                     "Taylor & Francis")


## restrict attention to the main publishers only

dfplot <- df %>% 
  filter(publisher %in% main_publishers) %>% 
  filter(year >= 2013 & year <= 2022)

##### 2. Fig 1B plot ####

Fig1B<-dfplot %>% 
  group_by(publisher, year) %>% 
  summarise(N = sum(Ndocs)) %>% 
  ggplot(aes(year, N, color = publisher))+
  geom_line(linewidth =1.3)+
  scale_y_continuous(labels = scales::label_number(scale_cut = cut_short_scale())) +
  gghighlight::gghighlight(publisher %in% c("MDPI", "Elsevier", 
                                            "Frontiers",
                                            "Springer", "BMC",
                                            "Hindawi", "PLOS",
                                            "Wiley","Nature",
                                            "Taylor & Francis"), 
                           label_params = list(direction = "y", nudge_x = 4, hjust = 1, size = 8), 
                           use_group_by = F, label_key = publisher)+
  scale_x_continuous(breaks = seq(2013, 2022, by = 3), expand = c(0, .3))+
  #scale_color_brewer(palette = "Set1")+
  theme(
    axis.title.y.left = element_text(color = "black", size = 24),
    axis.text.y.left = element_text(color = "black", margin = margin(r = 3, l = +30), size = 18),
    panel.grid.major.x = element_blank(),
    axis.text.x = element_text(color = "black", margin = margin(r = 3), size = 18)
    )+
  scale_color_manual(values = publisher_color_mapping) +
  labs(#title = "Number of articles published each year by publisher, 2013-22",
       y = "Total articles",
       x = "", 
       caption = "Source: Scimago website data")

ggsave("Figures/Building blocks/Fig1B_N_papers_per_publisher.png", Fig1B,
       height = 9/1.1, width = 14/1.1, units = "in", dpi = 300)


## sharing
sharing_Fig1B_raw<-dfplot %>% 
  group_by(publisher, year) %>% 
  summarise(N = sum(Ndocs))

write.csv(sharing_Fig1B_raw,"data sharing/Fig1B_raw.csv",row.names = FALSE)
