###
### The Strain on Scientific Publishing - 0_Packages_Install_Load.R
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description:
### install all dependencies (libraries) if necessary and load them
###


packages<-c("webshot2",                        # allows to export .png of {gt} tables
  ## generic tools
  "agricolae",                                 # 
  ## tables
  'gt',                                        # formatting and exporting nice-looking tables
  'gtExtras',                                  # extra tools for {gt}
  'kableExtra',                                # extra tools for {kable} tables
  ## ggplot addons
  "ggbeeswarm",                                # quasirandom point plot
  'hrbrthemes',                                # nice looking plots theme
  "ggtext",                                    # markdown support in plots
  "waffle",                                    # waffle charts
  "patchwork",                                 # compose different plots side-by-side
  "scales",                                    # extra scales for ggplot
  "ggstatsplot",                               # creates publication-ready and stats-fully-loaded plots
  ## reject rates libraries
  "here",
  "grid",
  "gridExtra",
  "readxl",
  "purrr",
  ## used for statistical letter groups after anova
  "multcomp",
  "multcompView",
  "emmeans",
  ## glm plots and RR analysis
  "sjPlot",
  "MuMIn",
  "conflicted",
  "magick",
  "janitor",
  "lubridate",
  "tidyverse",                                 # the R dialect used in the scripts
  "grateful")

installed_packages <- packages %in% rownames(installed.packages())
if (any(installed_packages == FALSE)) {
  install.packages(packages[!installed_packages])
}

lapply(packages, library, character.only = TRUE)


#Avoid conflicts
select <- conflicts_prefer(dplyr::select)
lag    <- conflicts_prefer(dplyr::lag)
filter <- conflicts_prefer(dplyr::filter)

rm(packages,installed_packages)