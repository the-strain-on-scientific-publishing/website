###
### The Strain on Scientific Publishing - Summary_Table_Overall.R
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description: 
### Summary table with one line per publisher, summarising strain indicators
###
###
### This script relies in Summary_table scripts and uses INDICATOR over different publishers


## treating: N
N <- summary_table_N %>% 
  mutate(delta_N_perc = round(100*(N_2022 - N_2016)/N_2016)) %>% 
  select(publisher, ends_with("2022"), starts_with("delta"))

## treating: %SI
SI <- summary_table_SI %>% 
  mutate(delta_SI_pp = round(100*(SI_2022 - SI_2016)), 
         SI_2022 = round(100*SI_2022)) %>% 
  select(publisher, ends_with("2022"), starts_with("delta"))
  
## treating: TAT
TAT <- summary_table_TAT %>% 
  mutate(delta_TAT_days = round(mlag_TAT_2022 - mlag_TAT_2016), 
         mlag_TAT_2022 = round(mlag_TAT_2022)) %>% 
  select(publisher, TAT_2022 = mlag_TAT_2022, starts_with("delta")) %>% 
  # fixing "Tay & Fran"
  mutate(publisher = if_else(publisher == "Tay. & Fran.", "Taylor & Francis", publisher))

## trating: RR
RR <- summary_table_RR %>% 
  mutate(RR_before = case_when(publisher %in% c("Frontiers", "MDPI", "PLOS") ~ RR_2016,
                               publisher %in% c("Elsevier", "Overall")       ~ RR_2018, 
                               publisher == "Hindawi"                        ~ RR_2020)) %>% 
  select(publisher, RR_before, RR_2022) %>% 
  mutate(delta_RR_pp = round(100*(RR_2022 - RR_before))) %>% 
  select(publisher, ends_with("2022"), starts_with("delta"))

### treating: IFI
IFI <- summary_table_IFI %>% 
  mutate(delta_IFI_perc = IFI_2022 - IFI_2016)%>% 
  select(publisher, ends_with("2022"), starts_with("delta")) 

## extra
##
## there is extra info on SELF CITES and on TAT variance
## this can be added to the table but is not right now


## merging
SumTab <- N %>% 
  full_join(SI, by = join_by(publisher)) %>% 
  full_join(TAT, by = join_by(publisher)) %>% 
  full_join(RR, by = join_by(publisher)) %>% 
  full_join(IFI, by = join_by(publisher)) %>% 
  arrange(-N_2022) %>% 
  select(publisher, ends_with("2022"), starts_with("delta")) %>% 
  # filtering away all publishers with lower N than PLOS
  filter(N_2022 > 19200)

## formatting
SumTab <- SumTab %>% 
  # renaming and formatting indicators for 2022
  rename(N = N_2022, SI = SI_2022, TAT = TAT_2022, RR = RR_2022, IFI = IFI_2022) %>% 
  mutate(SI = if_else(!is.na(SI), paste0(SI, "%"), "--"),
         TAT = if_else(!is.na(TAT), paste0(TAT, ""), "--"),
         RR = round(100*RR),
         RR = if_else(!is.na(RR), paste0(RR, "%"), "--"), 
         IFI = round(IFI, 1)) %>% 
  # renaming and formatting delta indicators
  rename(dN = delta_N_perc, dSI = delta_SI_pp, dTAT = delta_TAT_days, 
         dRR = delta_RR_pp, dIFI = delta_IFI_perc) %>% 
  mutate(dN = if_else(dN > 0, paste0("+", dN, "%"), paste0(dN, "%")), 
         dSI = if_else(!is.na(dSI),
                       if_else(dSI > 0, paste0("+", dSI, "pp"), paste0(dSI, "pp")),
                       "--"),
         dTAT = if_else(!is.na(dTAT), 
                        if_else(dTAT > 0, paste0("+", dTAT, ""), paste0(dTAT, "")),
                        "--"), 
         dRR = if_else(!is.na(dRR), 
                        if_else(dRR > 0, paste0("+", dRR, "pp"), paste0(dRR, "pp")),
                       "--"),
         dIFI = if_else(dIFI > 0, paste0("+", round(dIFI, 1)), paste0(dIFI)))
       

## final fomratting
formatted_tab_selected <- SumTab %>% 
  mutate(N = paste0(round(N/1000), "k")) %>% 
  filter(publisher %in% c("Overall", "Elsevier", "MDPI", "Springer", "Wiley", 
                          "Frontiers", "Taylor & Francis", "Nature", "BMC", "Hindawi", "PLOS")) %>% 
  mutate(dRR = if_else(publisher == "Elsevier", paste0(dRR, "*"), dRR)) %>% 
  mutate(dRR = if_else(publisher == "Hindawi", paste0(dRR, "°"), dRR)) %>% 
  rename(` ` = publisher, `TOTAL ARTICLES` = N,
         `Share Special Issue` = SI, `Turnaround time (days)` = TAT, `Rejection Rate` = RR, `Impact inflation` = IFI, 
         `total articles` = dN, `share special issue` = dSI, `RejeCtion rate` = dRR, `TurnAround time (days)` = dTAT, `Impact infLation` = dIFI) %>% 
  gt() %>% 
  gt_theme_538() %>% 
  opt_table_font(font = "Roboto") %>% 
  tab_options(table.width = 1150, container.width = 1200, heading.title.font.weight = "bold") %>% 
  cols_align(align = "center", columns = -` `) %>% 
  tab_spanner(label = "2022", columns = 2:6) %>% 
  tab_spanner(label = "Change 2016-22", columns = 7:11) %>% 
  tab_header(title = "Strain indicators at a glance: 2022 and evolution 2016-22") %>% 
  #tab_source_note(source_note =  "Source: data scraped on the publishers' website or publishers' own publications.
  #                                Overall: SI, TAT, Rejection % based on publishers with available data only. N papers, IF inflation, based on whole Scimago dataset.
  #                                Elsevier: rejection rate change starts from 2018. All publishers: Special Issues sometimes named differently.") %>% 
  tab_style(style = list(cell_borders(sides = "bottom", color = "black", weight = px(2))), 
            cells_body(rows = ` ` == "Overall")) %>% 
  tab_style(style = list(cell_borders(sides = "bottom", color = "black", weight = px(2))), 
            cells_body(rows = ` ` == "PLOS"))

formatted_tab_selected

## saving the table
formatted_tab_selected %>% 
  gtsave("Tables/tab_1_html.htm")

webshot2::webshot("Tables/tab_1_html.htm", file = "Tables/Table2_strainsummary.png", zoom = 5, vwidth = 1200)
