#### 0. Libraries ####
source("Scripts/0_Packages_Install_Load.R")
#### 0. Settings ####
source("Scripts/0_initial_settings.R")
#### 0. helper functions ####
source("Scripts/helper_functions.R")

#### some extra libraries
library(rcrossref)
library(httr)

# Your list of DOIs
## Load data independently to avoid filtering
unzip(zipfile = "Shiny_app/Data/SI_TAT_justDOIs.zip", 
      exdir= "Shiny_app/Data/")
SI_TAT_justDOIs <- read_csv("Shiny_app/Data/SI_TAT_justDOIs.csv") 
unlink("Shiny_app/Data/clean_data_all_publishers_lag.csv")

# Extract DOIs from your data frame
DOIs <- SI_TAT_justDOIs$DOI  # Assuming "DOI" is the actual name of your DOI column
head(DOIs)
length(DOIs) # 5,822,670

indices <- grep(".com", DOIs)
# Subset DOIs to get elements with ".com"
dotcom_DOIs <- unique(DOIs[indices])
head(dotcom_DOIs)
unique_prefixes <- unique(sub("https://(.*).com.*", "\\1", dotcom_DOIs))
head(unique_prefixes)
length(unique_prefixes) # 63722


cleaned_DOIs<-DOIs # [1:20] # reduce list for troubleshooting
## Clean up DOIs by removing "https://doi.org/"
cleaned_DOIs <- gsub("https://doi.org/", "", cleaned_DOIs)
# cleaned_DOIs <- gsub("https://", "", cleaned_DOIs)
# cleaned_DOIs <- gsub("doi.org/", "", cleaned_DOIs)
head(cleaned_DOIs)
length(cleaned_DOIs) # 5822670

###
# FOR NOW, JUST DO THE ONES THAT ARE SIMPLE doi.org/___ links
###
doiorg_DOIs <- cleaned_DOIs[grep("^10\\.", cleaned_DOIs)]
length(doiorg_DOIs) # 3404937 left
doiorg_DOIs<-doiorg_DOIs[1:200] # reduce list for troubleshooting

# Initialize the data frame with NAs
crossref_dois_df <- data.frame(
  DOI = doiorg_DOIs,
  journal = rep(NA, length(doiorg_DOIs)),
  issn = rep(NA, length(doiorg_DOIs)),
  publisher = rep(NA, length(doiorg_DOIs)),
  stringsAsFactors = FALSE
)

## time the loop by recording the start time
start_time <- Sys.time()
# Loop through each DOI and fetch information from CrossRef using rcrossref
for (i in seq_along(doiorg_DOIs)) {
  doi <- doiorg_DOIs[i]
  
  # Fetch metadata for the DOI using rcrossref
  doi_metadata <- cr_works(doi = doi, format = "parsed")
  
  # Extract relevant information and update the data frame
  crossref_dois_df[i, c("journal", "issn", "publisher")] <- c(
    ifelse(!is.null(doi_metadata$data$container.title), doi_metadata$data$container.title, NA),
    ifelse(!is.null(doi_metadata$data$issn), doi_metadata$data$issn, NA),
    ifelse(!is.null(doi_metadata$data$publisher), doi_metadata$data$publisher, NA)
  )
}
# time the loop by recording the end time
end_time <- Sys.time()
# Calculate and print the time taken
time_taken <- end_time - start_time
time_seconds<-as.numeric(difftime(end_time, start_time, units = "secs"))
time_taken
time_seconds
# checking 200 DOIs took 0h1m48s = 108s on Mark's HP, next run 1m51s = 111s

# length(doiorg_DOIs) = 3404937, or 5822670 total DOIs
process_rate<-110/200 # 110s/200DOIs = 0.55 s/DOI
cat("about", process_rate, "seconds per DOI")
time_per_DOI<-process_rate*5822670 # 1872715s for 3404937 DOIs
time_per_DOI
# Convert seconds to hours
time_in_days <- (time_per_DOI / 3600)/24
cat("about", time_in_days, "days for the full list") #"\n") # "\n" is the newline character
# rcrossref approach would take 37 days to process full dataset if it worked
# rcrossref approach would take 22 days to process just the good DOIs with doi.org names

print(crossref_dois_df)

write.csv(crossref_dois_df,"Shiny_app/Data/DOI_data_CrossRef.csv")
