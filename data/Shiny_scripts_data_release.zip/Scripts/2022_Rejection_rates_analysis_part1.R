###
### The Strain on Scientific Publishing
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description:
### 2022 young journal rejection rates analysis
###
###



PGB_2022_Rejection_rates <- read_csv("Data/reject_rates_subfiles/PGB_2022_Rejection_rates.csv")%>%
  mutate(journal_age=2023-first_year)%>%
  filter(publisher!="PLOS")%>%
  filter(journal_age<=10)
  

## Question: are young journal rejection rates different across publishers in 2022?

RR_aov<-aov(data=PGB_2022_Rejection_rates, RR~publisher)

summary(RR_aov)

Tukey <- HSD.test(RR_aov,"publisher", group=TRUE,console=TRUE)


Tukey_plot_table<- Tukey$groups%>%
  rownames_to_column()%>%
  rename(publisher=rowname)%>%
  left_join(Tukey$means)


ggplot(Tukey_plot_table,aes(x=publisher,y=RR,colour=publisher))+
  geom_pointrange(aes(ymin=RR-se,ymax=RR+se),size=.8, linewidth=1.2)+
  scale_color_manual(values=c("#c86434","#c55d93","#4bafd0","#6a7732","#55af7d"))+
  geom_text(aes(label=groups, y=RR+se+.02),color="black")+
  guides(color="none")+
  labs(y="Average Rejection Rate (2022)",x="",caption="Source: 2022 Rejection rates from publishers provided individual rejection rates for journals")

ggsave("Figures/Building blocks/FigX_2022_RR_stats.png",dpi="retina",height = 5.82,width=5.74)


## Hindawi

Hindawi_RR<-PGB_2022_Rejection_rates%>%
  filter(publisher=="Hindawi")%>%
  mutate(inflation= cit_per_doc_2 / SJR)

model<-glm(data=Hindawi_RR, RR~SJR*journal_age*Ndocs,na.action = "na.fail")

to_dredge<-dredge(rank = "AICc",global.model = model)

Hindawi_Models_under_2delta<-to_dredge%>%filter(delta<=2)
Hindawi_Models_under_2delta$Publisher<-"Hindawi"


## Taylor & Francis

TaylorFrancis_RR<-PGB_2022_Rejection_rates%>%
  filter(publisher=="Taylor&Francis")%>%
  mutate(inflation= cit_per_doc_2 / SJR)

model<-glm(data=TaylorFrancis_RR, RR~SJR*journal_age*Ndocs,na.action = "na.fail")

to_dredge<-dredge(rank = "AICc",global.model = model)

Taylor_Models_under_2delta<-to_dredge%>%filter(delta<=2)

Taylor_Models_under_2delta$Publisher<-"Taylor and Francis"


## Elsevier

Elsevier_RR<-PGB_2022_Rejection_rates%>%
  filter(publisher=="Elsevier")%>%
  mutate(inflation= cit_per_doc_2 / SJR)

model<-glm(data=Elsevier_RR, RR~SJR*journal_age*Ndocs,na.action = "na.fail")

to_dredge<-dredge(rank = "AICc",global.model = model)

Elsevier_Models_under_2delta<-to_dredge%>%filter(delta<=2)

Elsevier_Models_under_2delta$Publisher<-"Elsevier"

## MDPI

MDPI_RR<-PGB_2022_Rejection_rates%>%
  filter(publisher=="MDPI")%>%
  mutate(inflation= cit_per_doc_2 / SJR)

model<-glm(data=MDPI_RR, RR~SJR*journal_age*Ndocs,na.action = "na.fail")

to_dredge<-dredge(rank = "AICc",global.model = model)

MDPI_Models_under_2delta<-to_dredge%>%filter(delta<=2)

MDPI_Models_under_2delta$Publisher<-"MDPI"

### summarise

summary_table<-bind_rows(Elsevier_Models_under_2delta,Hindawi_Models_under_2delta,MDPI_Models_under_2delta,Taylor_Models_under_2delta)%>%
  as_tibble()%>%
  relocate(Publisher)

summary_table%>%gt()

write.csv(summary_table,"Tables/RR_2022_by_publisher_glms.csv")


