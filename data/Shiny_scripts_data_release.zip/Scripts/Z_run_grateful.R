###
### The Strain on Scientific Publishing - Z_run_grateful.R
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description: 
###
### Creates updated references for used libraries during Analysis.R
###

cite_packages(out.dir = "Tables",pkgs="Session",dependencies = FALSE)

