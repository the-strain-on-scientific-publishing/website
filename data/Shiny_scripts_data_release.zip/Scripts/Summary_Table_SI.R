###
### The Strain on Scientific Publishing - Fig2_Special_Issues_Other.R
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description:
###
###
### Save the share of SI papers out of total papers in 2013 and 2022 as well as the rate of change thereof for the final table
###
###

wfd <- SIdata %>% 
  filter(publisher != "peerj") %>% 
  mutate(publisher = case_when(publisher == "bmc" ~ "BMC", 
                               publisher == "frontiers" ~ "Frontiers", 
                               publisher == "hindawi" ~ "Hindawi",
                               publisher == "mdpi" ~ "MDPI",
                               publisher == "nature" ~ "Nature",
                               publisher == "plos" ~ "PLOS",
                               publisher == "springer" ~ "Springer",
                               publisher == "wiley" ~ "Wiley",
                               TRUE ~ publisher))

## overall
share_si_overall <- wfd %>%  
  group_by(year, SI) %>% 
  summarise(n = sum(n)) %>% 
  filter(year == "16" | year == "22") %>% 
  pivot_wider(names_from = SI, values_from = n) %>% 
  mutate(publisher = "Overall") %>% 
  mutate(shareSI = `Special Issue`/(`Regular Issue` + `Special Issue`)) %>% 
  dplyr::select(publisher, year, shareSI) %>% 
  mutate(year = as.numeric(year) + 2000) %>% 
  pivot_wider(names_from = year, values_from = shareSI, names_prefix = "SI_")
  

## by publisher
share_si_pub <- wfd %>% 
  filter(year == "16" | year == "22") %>% 
  pivot_wider(names_from = SI, values_from = n) %>% 
  mutate(shareSI = `Special Issue`/(`Regular Issue` + `Special Issue`)) %>% 
  dplyr::select(publisher, year, shareSI) %>% 
  mutate(year = as.numeric(year) + 2000) %>% 
  pivot_wider(names_from = year, values_from = shareSI, names_prefix = "SI_")

## binding
summary_table_SI <- bind_rows(share_si_overall, share_si_pub)

## cleaning up
rm(share_si_overall, share_si_pub, wfd)
