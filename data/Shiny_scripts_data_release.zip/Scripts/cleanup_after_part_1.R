###
### The Strain on Scientific Publishing - cleanup_after_part_1.R
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description:
### To reduce memory footprint & speed up R, delete objects that will not be needed from now on
###
###

## figures
rm(Fig1supp1A, Fig1supp1B, Fig1supp1C, Fig1supp1D, Figure1supp1, journal_growth_plot)

## imagemagick images
rm(combined_image, i, image1, image2, white_space)

## main dfs
rm(df, combined_df, combined_df2, corrected_df, corrected_df2, df_chinaPhDs, df_india_test, 
   df_IndiaPhDs, df2, dfplot)

## supporting dfs
rm(OECD_data, new_df_phds, stacked_df, TotalArticles2, TotalArts, TotalDocs,
   TotalPhDs, TotalPhDs2)

## other dfs
rm(new_years, unesco_df2, unesco_world, values_2015_to_2020)

## vectors and scalars
rm(coefficients, estimated_value, IndiaPhDs, IndiaYear, scaleFactor,
   year, WorldRow, text_labels, trendline_equation)

## models and predictions
rm(model, predicted_phds, predicted_phds2)

## clean memory
gc()
