###
### The Strain on Scientific Publishing - Table1.R
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description:
### Produces supplement figures to Figure 1
### Produces Table 1
###

# this uses the "df" from Phase 2

pubs <- c("bmc", "elsevier", "frontiers", "hindawi",
          "mdpi", "nature","springer","taf","plos",
          "wiley")

cut_off<-df%>%
  drop_na(lag)%>%
  filter(publisher %in% pubs)%>%
  filter(lag<=730)%>%
  filter(lag>0)%>%
  group_by(publisher)%>%
  summarise(n=n())

cut_off_journal<-df%>%
  drop_na(lag)%>%
  filter(publisher %in% pubs)%>%
  filter(lag<=730)%>%
  filter(lag>0)%>%
  mutate(journal=gsub("-.*","",journal))%>%
  distinct(publisher,journal)%>%
  group_by(publisher)%>%
  summarise(n=n())%>%
  rename(total_j=2)


# This part uses scimago data from Phase 1 again

scimago <- read_csv("Data/Scimago_data_filtered.csv") 
ID <- read_csv("Data/sjr_ID_to_publisher.csv") 

scimago <- scimago %>% 
  left_join(ID, by = join_by(journal, publisher))
rm(ID)

#### 2. Data cleaning ####

## First, assign different publisher names to the correct publisher

scimago_data <- clean_publisher_names(scimago)

pubs <- c("BMC", "Elsevier", "Frontiers", "Hindawi",
          "MDPI", "Nature","Springer","Taylor & Francis","PLOS",
          "Wiley")

selection<-scimago_data %>% #df comes from scimago
  filter(year>=2016)%>%
  filter(year<=2022)%>%
  filter(publisher %in% pubs)%>%
  group_by(publisher)%>%
  summarise(Total_pubs=sum(Ndocs))%>%
  arrange(publisher)%>%
  mutate(publisher=gsub("BMC","BMC*",publisher),
         publisher=gsub("Hindawi","Hindawi*",publisher),
         publisher=gsub("Nature","Nature*",publisher))

selection_journals<-scimago_data %>% #df comes from scimago
  filter(year>=2016)%>%
  filter(year<=2022)%>%
  filter(publisher %in% pubs)%>%
  distinct(publisher, title)%>%
  group_by(publisher)%>%
  summarise(n_j_scimago=n())%>%
  arrange(publisher)
 

## Table 1

final_table<-cbind(selection,cut_off,cut_off_journal,selection_journals)%>%
  select(1,6,4,2,8)%>%
  rename(Publisher=publisher, 
         'Web scraped journals included'=total_j,
         'Articles with turnaround times'=n,
         'Total articles (Scimago)'=4,
         'Total journals (Scimago)'=5)%>%
  relocate(1,2,3,5,4)

Table1 <- final_table%>%gt()%>%
  tab_options(table.width = 500,container.width = 900) %>% 
  opt_align_table_header(align = "center")%>%
  cols_align(
    align = c("center"),
    columns = everything())%>%
  tab_footnote(
    footnote = "Time period 2016-2022",
    locations = cells_column_labels(columns = 'Articles with turnaround times')
  )%>%
  tab_footnote(
    footnote = "Time period 2016-2022",
    locations = cells_column_labels(columns = 'Total articles (Scimago)')
  ) 

# saving the table: htm and png
Table1 %>% 
  gtsave("Tables/Table1.htm")

webshot2::webshot("Tables/Table1.htm", file = "Tables/Table1.png", zoom = 2 )

# trimming the table of all its whitespace

im <- magick::image_read("Tables/Table1.png")

im<-image_trim(im)

image_write(im, "Tables/Table1.png")

# cleanup
rm(Table1,scimago,scimago_data,final_table,cut_off,selection, selection_journals, cut_off_journal,im)
