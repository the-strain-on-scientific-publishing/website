###
### The Strain on Scientific Publishing - Fig1_calcs_strain_numbers_by_publisher.R
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description:
### computing contributions to strain and other numbers cited in the introduction and section 1 of results
###


#### 1. getting the data and the corresponding ID to publisher table in ####

## source of this is SCIMAGO
df <- read_csv("Data/Scimago_data_filtered.csv") 
ID <- read_csv("Data/sjr_ID_to_publisher.csv") 

df <- df %>% 
  left_join(ID, by = join_by(journal, publisher))
rm(ID)

#### 2. Data cleaning ####

## First, assign different publisher names to the correct publisher

df <- clean_publisher_names(df)

#### 3. larger publishers by output, larger publisher by added strain

# Largest publishers 2022
Top10<-top_publishers <- df %>%
  filter(year == 2022) %>%
  group_by(publisher) %>%
  summarize(total_Ndocs = sum(Ndocs)) %>%
  arrange(desc(total_Ndocs)) %>%
  head(10)

# save to file
Top10 %>% 
  write.csv("Tables/Fig1supp_top10_publishers.csv")

rm(Top10)

# Largest publishers contributing to strain in 2016->2022
N_unique_publishers <- df %>%
  filter(Ndocs > 0) %>%
  distinct(publisher) %>%
  n_distinct()

StrainTop10 <- df %>%
  filter(year %in% c(2016, 2022)) %>%
  group_by(publisher) %>%
  summarize(`2016` = sum(Ndocs[year == 2016]),
            `2022` = sum(Ndocs[year == 2022]),
            change = `2022` - `2016`,
            total_change = sum(change),
            change_percent = (change / total_change) * 100) %>%
  arrange(desc(change)) %>%
  head(N_unique_publishers) %>%
  select(publisher, `2016`, `2022`, change, change_percent) %>%
  ungroup() %>%
  mutate(change_percent = ifelse(is.na(change_percent), 0, change_percent)) %>%
  mutate(change_percent = (change / sum(change)) * 100)
StrainTop10

sum_top_5_change_percent <- sum(top_n(StrainTop10, 5)$change_percent)
sum_top_5_change_percent # 70.67938, or 69.90675 without areas = "Arts and Humanities." Rounded publisher numbers remain largely unchanged (Springer rounds to 9% instead of 10%)

# save to file
write.csv(StrainTop10, "Tables/Fig1supp_strain_summary.csv", row.names = FALSE)

# cleanup
rm(N_unique_publishers, StrainTop10, sum_top_5_change_percent)

#### 4. supporting our claim that growth is exponential ####


growth_rates <- df %>% 
  group_by(year) %>% 
  summarise(N = sum(Ndocs)) %>% 
  mutate(growth = (N/lag(N) - 1))

# result: growth has ALWAYS been >3% a year since 1999
# constant rate of growth in a series >> exponential growth


## compound average growth rate 2016-22: 5.62%
(growth_rates$N[growth_rates$year==2022]/growth_rates$N[growth_rates$year==2016])^(1/7) - 1

## cleanup
rm(growth_rates)

