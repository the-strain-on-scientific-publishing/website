###
### The Strain on Scientific Publishing - Fig5_Inflation.R
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description:
### Generates figure 5A -- Impact Inflation for selected publishers
###
###
###

## Return to original dataframe from N_papers_and_PhDs.R (avoids renaming everything in scripts)

df <- read_csv("Data/Scimago_data_filtered.csv") 
ID <- read_csv("Data/sjr_ID_to_publisher.csv") 

df <- df %>% 
  left_join(ID, by = join_by(journal, publisher))
rm(ID)

df$inflation <- df$cit_per_doc_2/df$SJR

df <- clean_publisher_names(df)


##### 1. Prepare data #######

## subset of publishers considered in Fig. 5

subset_publishers <- c(
  "MDPI",
  "Nature",
  "Springer",
  "Elsevier",
  "Frontiers",
  "Wiley",
  "PLOS",
  "BMC",
  "Hindawi",
  "Taylor & Francis"
)


############################################
# Fig5a
############################################

## Figure 5a, Impact Inflation by publisher

Inflation_2022<-df %>% 
  filter(year == 2022) %>% 
  mutate(inflation = inflation) %>% 
  filter(publisher %in% subset_publishers) %>%
  group_by(year, publisher) %>% 
  mutate(meaninf = mean(inflation, na.rm = T)) %>% 
  ggplot(aes(inflation, reorder(publisher,meaninf)))+
  geom_jitter(aes(fill = publisher), height = 0.4, width = 0, size = 2,
              alpha = 0.1, shape = 21, color = "grey50")+
  geom_violin(alpha = 0.1, adjust = 1.5)+
  geom_boxplot(width=0.1, alpha = 0.1)+
  scale_fill_manual(values = sapply(df$publisher, get_publisher_color)) +
  theme(legend.position = "none")+
  scale_x_continuous(breaks = c(0,2,4,6,8,10), limits = c(0,10))+
  labs(title = "Impact inflation, 2022", 
       subtitle = "2y cites over SJR", 
       y = "",
       x = "IF inflation", 
       caption = "Source: Scimago website data")
Inflation_2022

## Author note: x-axis (plot only) limited to 10 to avoid stretching to show just a few outliers
## Modify above scale_x_continuous(... limits = c(0,10)) to show full data including outliers 

############################################
### STATISTICS Fig5a
############################################

## Prepare data as 2022 only, filtering to remove zero values for inflation (likely to be a subset of journals with indexing dropouts)

dfTK<-df %>%
  filter(inflation > 0,
         year == 2022,
         publisher %in% subset_publishers)

# Data transformations (modifications for to better ensure assumptions of normality, explained further below)

dfTK$inv_inflation <- 1/dfTK$inflation # inverse value as transformation to normalise data
dfTK$sqrtinv_inflation <- sqrt(dfTK$inflation) # square root as transformation to normalise data
dfTK$publisher <- as.factor(dfTK$publisher)
head(dfTK)

### ANOVAs

res.aov <- aov(inflation ~ publisher, data = dfTK)
summary(res.aov)

res.aov.sqrtinv <- aov(sqrtinv_inflation ~ publisher, data = dfTK)
summary(res.aov.sqrtinv)

# QQplots covered by # to run code quicker, but can be removed here to show

# plot(res.aov, 1, cex=0.2)
# plot(res.aov, 2,cex=0.2)

## shows there is a strong right skew to the data, leading to greater significance that is not robust to data normalisation

# 
# plot(res.aov.sqrtinv, 1, cex=0.2)
# plot(res.aov.sqrtinv, 2,cex=0.2) 

## The double transformation of inverse and square root does a fantastic job of normalising the data's distribution
## This treatment is carried forward for final impact inflation statistics.
## Major conclusions do not change with/without this data normalisation, though strength of effect does.


### Multiple comparisons using both raw data and transformed data, providing .csv table outputs for scrutiny of trends

# raw data
TK<-TukeyHSD(res.aov)
TK
TK_data<-as.data.frame(TK[1])
write.csv(TK_data, 'Tables/ImpactInflation_2022_TukeyHSD.csv')


TK_data<-as.data.frame(TK[1])
TK <- emmeans(res.aov, "publisher")

# Generate letter-based grouping for multiple comparisons of raw data
letter_groups <- cld(TK, Letters = letters)
letter_groups
write.csv(letter_groups, 'Tables/ImpactInflation_2022_TukeyHSD_lettergroups.csv')

# transformed data
TK<-TukeyHSD(res.aov.sqrtinv)
TK
TK_data<-as.data.frame(TK[1])
write.csv(TK_data, 'Tables/ImpactInflation_2022_sqrtinv_TukeyHSD.csv')

TK_data<-as.data.frame(TK[1])
TK <- emmeans(res.aov.sqrtinv, "publisher")

# Generate letter-based grouping for multiple comparisons of transformed data
letter_groups <- cld(TK, Letters = letters)
letter_groups
write.csv(letter_groups, 'Tables/ImpactInflation_2022_sqrtinv_TukeyHSD_lettergroups.csv')


### add letter groups to Fig5A

# Merge the letter_groups and meaninf data
merged_data <- merge(letter_groups, df, by = "publisher")
head(merged_data)

merged_data <- merged_data %>%
  filter(year == 2022) %>%
  filter(publisher %in% subset_publishers) %>%
  group_by(year, publisher) %>%
  mutate(meaninf = mean(inflation, na.rm = TRUE))
merged_data <- merged_data %>%
  mutate(.group = trimws(.group))


# plot Fig5A with statistical letter group annotations
Inflation_2022 <- ggplot(merged_data, aes(inflation, reorder(publisher, meaninf))) +
  geom_jitter(aes(fill = publisher), height = 0.4, width = 0, size = 2,
              alpha = 0.1, shape = 21, color = "grey50") +
  geom_violin(alpha = 0.1, adjust = 1.5) +
  geom_boxplot(width = 0.1, alpha = 0.1) +
  geom_text(aes(x = 9.5, label = merged_data$.group), 
            hjust = 0, vjust = 0, size = 6, color = "blue") + 
  scale_fill_manual(values = sapply(df$publisher, get_publisher_color)) +
  theme(legend.position = "none") +
  scale_x_continuous(breaks = c(0, 2, 4, 6, 8, 10), limits = c(0, 10)) +
  theme(
    axis.title.y.left = element_text(color = "black", size = 24),
    axis.text.y.left = element_text(color = "black", margin = margin(r = 3, l = +30), size = 18),
    axis.text.x = element_text(color = "black", margin = margin(r = 3), size = 18, vjust = 2),
    axis.title.x = element_text(color = "black", margin = margin(r = 3, l = +30), size = 18),
  )+
  labs(
    y = "",
    x = "Impact inflation",
    caption = 
    "The x-axis is limited at 10 to prevent the plot from stretching to show just a few major outliers
    Source: Scimago website data"
  )
Inflation_2022

Fig5A<-Inflation_2022
ggsave(plot=Inflation_2022, "Figures/Building blocks/Fig5a_2022_Inflation_Scimago_data.png", 
       height = 12/1.2, width = 12/1.2, units = "in", dpi = 300)
