###
### The Strain on Scientific Publishing - Fig1_supp_UNESCO.R
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description:
### produces supplement figures to Figure 1
###
###
###

## Fig1A supplement: OECD countries make up the majority of global PhDs awarded, but ignore major countries with growing academic industries such as China and India.
# What if we use UNESCO data?
# Why: because the OECD dataset does not include all countries, and PhD recruitment is only one proxy for total publishing researchers.
# caveat: researchers-per-million is also a proxy for total publishing researchers, and includes non-publishing researchers (government and industry researchers) that do not participate in the publishing infrastructure in the same way as academic researchers
####
# IMPORTANT NOTES ON UNESCO DATA
####
## The unesco data are lacking major countries in 2019-2020... and also UNESCO data start at 2015.
## We also cannot simply average the researchers per million across all countries, because this is not weighted by population size
## This means we would need to also collect population-level data for every unesco country per year and merge this into the dataset
## As many countries don't have researchers-per-million data past 2018, this representation of global researchers should be viewed with caution.
####
## Major countries missing data from 2019-on:
#### Canada, New Zealand (spotty reporting), Switzerland (spotty reporting), India
## Major countries missing data from 2020-on:
#### USA, UK, China (but estimates provided)
###


df2 <- df

# using the UNESCO data and the Scimago df that has been called so far
unesco_df2 <- read_csv("Data/UNESCO_researchers_per_mil.csv")

WorldRow<-unesco_df2[157, ] # row containing the World values
values_2015_to_2020 <- WorldRow[, c("2015", "2016", "2017", "2018", "2019", "2020")]
WorldRow <- c(as.numeric(values_2015_to_2020), "NA","NA")
year <- c(2015,2016,2017,2018,2019,2020,2021,2022)
unesco_world <- data.frame(WorldRow,year)
names(unesco_world) <- c("res_per_mil","year")
unesco_world

unesco_df2<-unesco_world # if you ignore this line, you can look at how the data behave per year with country-level resolution

TotalPhDs2 <- unesco_df2 %>% 
  filter(!is.na(as.numeric(res_per_mil))) %>%
  mutate(year = as.numeric(year)) %>%
  mutate(value = as.numeric(res_per_mil)) %>%
  group_by(year) %>%
  summarise(researchers = sum(value, na.rm = TRUE)) %>%
  ungroup()
TotalPhDs2 <- TotalPhDs2 %>%
  filter(year >= 2015 & year <= 2020)

TotalArticles2 <- df2 %>% 
  mutate(year = as.numeric(year)) %>% 
  group_by(year) %>% 
  summarise(N = sum(Ndocs)) %>% 
  ungroup()
TotalArticles2

combined_df2 <- left_join(TotalArticles2,TotalPhDs2, by = "year")

combined_df2 <- combined_df2 %>%
  filter(year >= 2015 & year <= 2022)

combined_df2

# actual plot for Fig1A


# facto to scale right-hand-side axis
scaleFactor <- (max(combined_df2$N) / max(combined_df2$researchers,na.rm=T))*.82

## what if we project 2021 and 2022 using unesco data?

corrected_df2<-combined_df2

# Fit the quadratic linear model using the data from 2013 to 2020
model <- lm(researchers ~ year, data = corrected_df2)
summary(model) # Adjusted R-squared:  0.9793, F-statistic: 237.3 on 1 and 4 DF,  p-value: 0.0001036

# Create a new dataframe for 2021 and 2022
new_years <- data.frame(year = c(2021, 2022))
# Predict the number of PhDs for 2021 and 2022 along with confidence intervals
predicted_phds2 <- predict(model, newdata = new_years, interval = "confidence", level = 0.95)
# Print the predicted values and confidence intervals
#print(predicted_phds2)
# fit      lwr      upr
# 1 333162.4 316326.9 349997.9
# 2 323564.6 297780.6 349348.7
# replace 2021 and 2022 with the values interpolated from quadratic expression
corrected_df2$researchers2 <- NA
corrected_df2$researchers2[corrected_df2$year == 2020] <- corrected_df2$researchers[corrected_df2$year == 2020]
corrected_df2$researchers2[corrected_df2$year == 2021] <- predicted_phds2[1]
corrected_df2$researchers2[corrected_df2$year == 2022] <- predicted_phds2[2]
corrected_df2

# facto to scale right-hand-side axis
scaleFactor <- (max(combined_df2$N) / max(combined_df2$researchers,na.rm=T))*.82

# figure
Fig1supp1C <-corrected_df2 %>% 
  ggplot(aes(x = year)) +
  # Total articles
  geom_line(aes(y = N), col = "black", linewidth = 1.5) +
  # N PhDs, scaled
  geom_line(aes(y = researchers * scaleFactor), col = "red", na.rm = TRUE, linewidth = 1.5, linetype = "dashed")+
  geom_line(aes(y = researchers2 * scaleFactor), col = "red", na.rm = TRUE, linewidth = 1, linetype = "dotted")+
  scale_y_continuous(name = "Total articles",
                     labels = millions_format,
                     sec.axis = sec_axis(~ . / scaleFactor, name = "Researchers (full-time equivalent) per capita",labels = thousands_format),
                     limits = c(1700000, 2900000),
                     breaks = seq(1700000, 3000000, by = 400000)) +  # Set limits for the left y-axis
  scale_x_continuous(breaks = seq(2013, 2021, by = 2)) +
  theme(
    axis.title.y.left = element_text(color = "black", size = 18),
    axis.text.y.left = element_text(color = "black", margin = margin(r = 3), size = 16),
    axis.text.y.right = element_text(color = "red", size = 16),
    axis.title.y.right = element_text(color = "red", angle = 270, hjust = 0, vjust = 1.5, size = 18),
    axis.text.x = element_text(size = 18),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    axis.ticks.y.left = element_line(),
    axis.ticks.y.right = element_line(color="red"),
    plot.margin = margin(t = 1, r = 1, b = 1, l = 1, unit = "cm")
  )+
  labs(title = "Newly published papers and average researchers per million per year, 2015-22", 
       subtitle = "Average researchers per million people (UNESCO)",
       caption = "Source: Total articles -- Scimago website data; Researchers per million - UNESCO", 
       x = "")

ggsave(plot=Fig1supp1C, "Figures/Building blocks/Fig1supp1C_N_Papers_per_unesco_researchers_world_projections.png", 
       width = 12/1, height = 9/1, unit = "in", dpi = 300)


corrected_df2$ratio <- corrected_df2$N/corrected_df2$researchers
corrected_df2$ratio2 <- corrected_df2$N/corrected_df2$researchers2

corrected_df2

# figure (exploratory) - it would be interesting to project the total PhDs into 2022 to see how extreme this ratio gets as Ndocs have only increased
Fig1supp1D <- corrected_df2 %>% 
  ggplot(aes(x = year)) +
  # Total articles
  geom_line(aes(y = ratio), col = "black", linewidth = 1.5, na.rm = TRUE) +
  geom_line(aes(y = ratio2), col = "black", linetype = "dotted", linewidth = 1, na.rm = TRUE) +
  scale_y_continuous(name = "Total articles / active researchers per million",
                     limits = c(1590, 2000),
                     breaks = seq(1600, 2000, by = 100)) +
  scale_x_continuous(breaks = seq(2016, 2022, by = 2))+
  labs(title = "Ratio total articles to researchers-per-million from UNESCO data", 
       subtitle = "How has the ratio of Ndocs:researchers changed over time? Dotted line = projected numbers",
       caption = "Source: Total articles -- Scimago website data; researchers-per-million - UNESCO", 
       x = "")+
  theme(
    axis.title.y.left = element_text(color = "black", size = 18),
    axis.text.y.left = element_text(color = "black", margin = margin(r = 3), size = 16),
    axis.text.x = element_text(size = 18), 
    panel.grid.major.x = element_blank()
  )

ggsave(plot=Fig1supp1D, "Figures/Building blocks/Fig1supp1D_unescoWorld_ratio_incl_projections.png", 
       width = 12/1.2, height = 9/1.2, units = "in", dpi = 300)

### using patchwork create Fig1 supp1 panels C and D

Figure1supp1 <- (Fig1supp1C + Fig1supp1D)
Figure1supp1 + plot_annotation(tag_levels = list(c('C','D'))) &
  theme(plot.tag = element_text(size = 36)) 
ggsave("Figures/Building blocks/Fig1supp1-2_patchwork.png", 
       width = 22, height = 8, units = "in", dpi = "retina")