###
### The Strain on Scientific Publishing - Summary_Table_SC.R
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description: 
### Save the Self-citation data we have for the final table
###
###


summary_SC_overall <- df_sc %>% 
  filter(year == 2016 | year == 2022) %>%
  group_by(year) %>% 
  summarise(SC = mean(share_self_cite, na.rm = T)) %>% 
  pivot_wider(names_from = year, values_from = SC, names_prefix = "SC_") %>% 
  mutate(publisher = "Overall") %>% 
  select(publisher, everything())

## by publisher
summary_SC_pub <- df_sc %>% 
  filter(year == 2016 | year == 2022) %>%
  filter(publisher %in% list_main_publishers) %>% 
  group_by(year, publisher) %>% 
  summarise(SC = mean(share_self_cite, na.rm = T)) %>% 
  pivot_wider(names_from = year, values_from = SC, names_prefix = "SC_") %>% 
  select(publisher, everything()) %>% 
  arrange(-SC_2022)

## saving
summary_table_SC <- bind_rows(summary_SC_overall, summary_SC_pub)
summary_table_SC # to insert into discussion

## cleanup
rm(summary_SC_overall, summary_SC_pub)