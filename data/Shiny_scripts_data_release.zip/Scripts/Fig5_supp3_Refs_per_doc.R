###
### The Strain on Scientific Publishing 
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description:
### Fig 5 supp 3: growth in references per document in recent years
### 
###

## Refs per doc
TotalRefs <- df %>% 
  mutate(year = as.numeric(year)) %>% 
  group_by(year) %>% 
  summarise(N = mean(Ref_per_doc)) %>% 
  ungroup()

TotalRefs <- TotalRefs %>%
  filter(year >= 2016 & year <= 2022)

TotalRefs %>%
  ggplot(aes(x = year)) +
  geom_line(aes(y = N), col = "black", size = 1.5) +
  scale_x_continuous(breaks = seq(2016, 2022, by = 2)) +
  theme(
    axis.title.y.left = element_text(color = "black"),
    axis.text.y.left = element_text(color = "black", margin = margin(r = 3)),
    axis.title.y = element_text(color = "black", vjust = 8, size = 14),
    axis.title.x = element_text(color = "black", size = 14), 
    panel.grid.major.x = element_blank()
  ) +
  labs(title = "References per document, 2016-22",
       y = "Total references per document",
       x = "",
       caption = "Source: Scimago website data")+
  theme(panel.grid.major.y = element_line(linetype = "dotted"), 
        legend.position = "none",
        panel.grid.minor.y = element_blank(),
        plot.title.position = "plot",
        axis.text.y = element_text(hjust = 0.5, size=16), 
        axis.title.y = element_text(size = 18),
        axis.title.x = element_text(size = 18),
        axis.text.x = element_text(size = 16), 
        legend.text = element_text(size = 14),
        legend.title = element_text(size = 14))

ggsave("Figures/Supplemental/Fig5_supp3.png", 
       width = 12/1, height = 9/1, unit = "in", dpi = 300)

rm(TotalRefs)

