###
### The Strain on Scientific Publishing - Fig5supp4_magick.R
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description: 
### Generates figure 5supp4 -- comparison of Cites per Doc (Scimago) to Impact Factor (Clarivate)
###
###
###

# Figure 5supp5A-D using magick, and also some white space defined
image1 <- image_read("Figures/Building blocks/Fig5_supp4a1_IFvsCitesPerDoc2yr_pre2022.png")
image2 <- image_read("Figures/Building blocks/Fig5_supp4a2_IFvsCitesPerDoc2yr_2022.png")
image3 <- image_read("Figures/Building blocks/Fig5_supp4b_2021_Inflation_Scimago_data.png")
image4 <- image_read("Figures/Building blocks/Fig5_supp4c_2022_Inflation_Scimago_data.png")
white_space_w <- image_blank(width = image_info(image1)$width, height = 100, color = "white") # Used to add white space above the images
white_space_h <- image_blank(height = image_info(image1)$height, width = 250, color = "white") # Used to add white space above the images

# Combine the images, including white space margins where needed
combined_image1 <- image_append(c(white_space_h, image1, image2), stack = F) # previously stack = T
combined_image2 <- image_append(c(white_space_h, image3, image4), stack = F) # previously stack = T
combined_image3 <- image_append(c(white_space_w, combined_image1, white_space_w, combined_image2), stack = T) # previously stack = T

image_write(combined_image3, path = "Figures/Building blocks/Fig5supp4_noletters.png")

input_image <- image_read("Figures/Building blocks/Fig5supp4_noletters.png")
text_labels <- c("A'", "A''", "B", "C")
text_locations <- c("+100+100","+3000+100", "+100+2400", "+3100+2400")
for (i in seq_along(text_labels)) {
  input_image <- image_annotate(input_image,
                                 text = text_labels[i],
                                 size = 128,
                                 color = "black",
                                 location = text_locations[i])
} # Add text annotations with specific locations

image_write(input_image, path = "Figures/Supplemental/Fig5_supp4_Inflation_n_selfcites_using_IF.png")
