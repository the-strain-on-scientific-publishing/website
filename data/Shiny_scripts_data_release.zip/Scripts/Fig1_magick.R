###
### The Strain on Scientific Publishing - Fig1_magick.R
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description:
### Produces Figure 1 using the magick package
###

#### 1. Stitching together the 3 building blocks to build Figure 1

img_Fig1A <- image_read("Figures/Building blocks/Fig1A_N_Papers_PhDs.png")
img_Fig1B <- image_read("Figures/Building blocks/Fig1B_N_papers_per_publisher.png")
img_Fig1C <- image_read("Figures/Building blocks/Fig1C_N_papers_per_journal_per_publisher.png")
white_space <- image_blank(width = image_info(img_Fig1A)$width, height = 100, color = "white") # Used to add white space above the images

combined_img <- image_append(c(white_space, img_Fig1A, white_space, img_Fig1B, white_space, img_Fig1C), stack = TRUE)
image_write(combined_img, path = "Figures/Figure_1.png")

input_image <- image_read("Figures/Figure_1.png")

text_labels <- c("A", "B", "C")
text_locations <- c("+50+50","+50+2800", "+50+5350")
for (i in seq_along(text_labels)) {
  input_image <- image_annotate(input_image,
                                text = text_labels[i],
                                size = 156,
                                color = "black",
                                location = text_locations[i])
} # Add text annotations with specific locations

image_write(input_image, path = "Figures/Figure_1.png")

# cleanup
rm(Fig1A, Fig1B, Fig1C, img_Fig1A, img_Fig1B, img_Fig1C)
rm(input_image, text_locations, combined_img)

