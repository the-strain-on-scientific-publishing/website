###
### The Strain on Scientific Publishing - Summary_Table_RR.R
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description:
### Save the RR data we have for the final table
###
###

### overall
RR_overall <- RRdf %>% 
  group_by(year) %>% 
  summarise(RR = mean(reject_rate, na.rm = T)) %>% 
  filter(year == "2018" | year == "2022") %>% 
  pivot_wider(names_from = year, values_from = RR, names_prefix = "RR_") %>% 
  mutate(publisher = "Overall") %>% 
  select(publisher, everything())

## by publisher

RR_publisher <- RRdf %>% 
  group_by(year, publisher) %>% 
  summarise(RR = mean(reject_rate, na.rm = T)) %>% 
  mutate(startyear = case_when(publisher %in% c("MDPI", "PLOS","Frontiers") ~ 2016, 
                               publisher == "Elsevier"          ~ 2018, 
                               publisher == "Hindawi"           ~ 2020), 
         endyear = 2022) %>% 
  filter(year == startyear | year == endyear) %>% 
  pivot_wider(names_from = year, values_from = RR, names_prefix = "RR_") %>% 
  select(-endyear, -startyear)

## saving
summary_table_RR <- bind_rows(RR_publisher, RR_overall)

## cleanup
rm(RR_overall, RR_publisher)
