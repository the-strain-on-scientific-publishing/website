###
### The Strain on Scientific Publishing - 0_Merge_raw_Scimago_data.R
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description: 
### Generates a single data frame with Scimago data combining a series of .csv files
### !slow
###

library(dplyr)

setwd("Data/raw_data_Scimago")

# a vector of final column names to rename columns in each dataframe, avoiding internal parentheses in column names
col_names <- c("rank","journal","title","type","issn",
               "SJR","SJR_bestquartile","h_index","Ndocs","Ndocs_3years",
               "total_refs","total_cites_3years","Citable_docs_3years","cit_per_doc_2","Ref_per_doc",
               "country","region","publisher","coverage","categories",
               "areas", "year")

# Get the current working directory as the folder path for the ensuing for-loop
csv_folder <- getwd()

# Get the list of CSV files in the folder
csv_files <- list.files(path = csv_folder, pattern = "\\.csv$", full.names = TRUE)

# Initialize an empty list to store the data frames
data_frames_list <- list()

# Read and combine the CSV files, and add the year as a new column
for (file in csv_files) {
  # Extract the last 4 characters of the file name as the year
  year <- substr(basename(file), nchar(basename(file)) - 7, nchar(basename(file)) - 4) # Assuming the year is always 4 characters before the file extension
  
  # Read CSV file with semicolon (;) as the separator and headers included
  df <- read.csv2(file, header = TRUE)
  
  # Add the 'Year' column with the extracted year
  df$Year <- as.integer(year)
  
  # rename colnames in a standardised way per df to deal with different years in colnames of different dataframes
  colnames(df) <- col_names
  
  data_frames_list <- c(data_frames_list, list(df))
}

# Merge the data frames using dplyr's bind_rows()
merged_df <- bind_rows(data_frames_list)

#names(merged_df) # sanity check to ensure columns are renamed correctly

head(merged_df)

# Retain only the necessary columns to reduce on file size before creating a new overarching master file to reduce file size
Scimago_data_filtered <- dplyr::select(merged_df, journal, title, issn, SJR, Ndocs, cit_per_doc_2, Ndocs_3years, total_cites_3years, Ref_per_doc, publisher, coverage, year, areas)
head(Scimago_data_filtered)

Scimago_data_filtered$cit_per_doc_3 <- Scimago_data_filtered$total_cites_3years/Scimago_data_filtered$Ndocs_3years
head(Scimago_data_filtered)

Scimago_data_filtered <- dplyr::select(Scimago_data_filtered, journal, title, issn, SJR, Ndocs, cit_per_doc_2, cit_per_doc_3, Ref_per_doc, publisher, coverage, year, areas)
head(Scimago_data_filtered)

setwd("..") # resets wd moving up one folder in path

write.csv(Scimago_data_filtered, "Scimago_data_filtered.csv")

setwd("..") # resets wd moving up one folder in path

