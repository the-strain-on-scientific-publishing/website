###
### The Strain on Scientific Publishing - 0_initial_settings.R
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description:
### Main plot theme, colors and other general settings
### 
###



## overall ggplot theme
theme_set(theme_ipsum_rc(base_family = "Roboto", base_size = 14)+
            theme(plot.background = element_rect(colour = "white", fill = "white"),
                  panel.grid.minor = element_blank(),
                  plot.title.position = "plot",
                  plot.caption = element_text(size = 13),
                  axis.title.x = element_text(hjust = .5),
                  axis.title.y = element_text(hjust = .5), 
                  plot.margin = margin(t = 0, r = 0, b = 0, l = 0, unit = "cm"))
)

## color palette

## comparing over time, we use these colors

time_comparison_colors <- c("#377EB8", "#529684", "#4DAF4A")

## for publishers, we use these colors
## palette comes from "iwanthue" and is intended to be as visually distinct for colour blind folks as possible

publisher_comparison_colors <- c("#c86434", "#4bafd0", "#cd555d", "#79b543", "#b05cc6", "#55af7d", "#c55d93", "#6a7732", "#7178ca", "#c79e48")

# making this for later when we want to call all publisher colours consistently across figures
list_main_publishers <- c("Elsevier", "MDPI", "Springer", "Wiley", "Frontiers", "Taylor & Francis", "Hindawi", "PLOS", "BMC", "Nature")


publisher_color_mapping <- setNames(publisher_comparison_colors, list_main_publishers)
