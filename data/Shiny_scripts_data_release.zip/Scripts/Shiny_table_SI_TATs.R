## here we create a table that we will use to feed a shiny app
##
## see the relevant documentation in the shiny app scripts
##
## but basically
##
## - for each publisher
## - for each journal
##    . we collect a set of data
##
## Here, as defined in "## Prepare TAT data table for shiny app":
##    - TAT median = "m" <- ??????
##    - TAT Standard Error of Mean = "diffsem"
##    - TAT confidence interval lower = "cil"
##    - TAT confidence interval higher = "cih"
##    - ??? = "label"


## Load data independently to avoid filtering
unzip(zipfile = "Data/clean_data_all_publishers_lag.zip", 
      exdir= "Data/")
SI_TATdata_shiny0 <- read_csv("Data/clean_data_all_publishers_lag.csv") 
unlink("Data/clean_data_all_publishers_lag.csv")

head(SI_TATdata_shiny0)
str(SI_TATdata_shiny0)

# sanity check
subpub_dataframe<-filter(SI_TATdata_shiny0, publisher=="springer")
head(subpub_dataframe)
subpub_dataframe<-filter(SI_TATdata_shiny0, publisher=="elsevier")
head(subpub_dataframe)
subpub_dataframe<-filter(SI_TATdata_shiny0, publisher=="peerj")
head(subpub_dataframe)
subpub_dataframe<-filter(SI_TATdata_shiny0, publisher=="bmc")
head(subpub_dataframe)
subpub_dataframe<-filter(SI_TATdata_shiny0, publisher=="frontiers")
head(subpub_dataframe)
subpub_dataframe<-filter(SI_TATdata_shiny0, publisher=="hindawi")
head(subpub_dataframe)
subpub_dataframe<-filter(SI_TATdata_shiny0, publisher=="mdpi")
head(subpub_dataframe)
subpub_dataframe<-filter(SI_TATdata_shiny0, publisher=="nature")
head(subpub_dataframe)
subpub_dataframe<-filter(SI_TATdata_shiny0, publisher=="plos")
head(subpub_dataframe)
subpub_dataframe<-filter(SI_TATdata_shiny0, publisher=="taf")
head(subpub_dataframe)
subpub_dataframe<-filter(SI_TATdata_shiny0, publisher=="wiley")
head(subpub_dataframe)
subpub_dataframe<-filter(SI_TATdata_shiny0, publisher=="nas")
head(subpub_dataframe)
subpub_dataframe<-filter(SI_TATdata_shiny0, publisher=="royal")
head(subpub_dataframe)

###
# springer filled its journal column using the suffix of the paper's doi in clean_data
# Pablo has now made a new clean_data2 that corrects this
###

# Export the list of DOIs to a .csv so we can feed it to CrossRef and download CrossRef metadata
just_DOIs<-SI_TATdata_shiny0$DOI
just_DOIs<-as.data.frame(just_DOIs)
colnames(just_DOIs)<-c("DOI")
head(just_DOIs)
#write.csv(just_DOIs, "Shiny_app/Data/SI_TAT_justDOIs.csv")

### Different from Analysis.R, we keep all publishers/journals for the Shiny app
### including PNAS, Royal Society, PeerJ, etc...
## subset the data and mutate() labels
SI_TATdata_shiny1 <- SI_TATdata_shiny0 %>% 
  filter(year >= 2016) %>% 
  mutate(publisher = case_when(
    publisher == "bmc" ~ "BMC", 
    publisher == "frontiers" ~ "Frontiers", 
    publisher == "hindawi" ~ "Hindawi",
    publisher == "mdpi" ~ "MDPI",
    publisher == "nature" ~ "Nature",
    publisher == "plos" ~ "PLOS",
    publisher == "springer" ~ "Springer",
    publisher == "taf" ~ "Taylor & Francis",
    publisher == "wiley" ~ "Wiley",
    publisher == "elsevier" ~ "Elsevier",
    publisher == "nas" ~ "PNAS",
    publisher == "peerj" ~ "PeerJ",
    publisher == "royal" ~ "The Royal Society",
    TRUE ~ publisher
  )) %>% 
  filter(lag > 0) %>% 
  filter(lag < 2*365) %>% 
  mutate(year = as.factor(year),
         lag = as.numeric(lag))

head(SI_TATdata_shiny1)
str(SI_TATdata_shiny1)
unique(SI_TATdata_shiny1$publisher)


## loop through
# I had an issue with summarise not recognizing all the publishers, so I specified the list directly
# Create an empty dataframe to store the results
SI_TATdata_shiny2 <- data.frame()

# Define the publishers to be looped through 'manually'
# I had a weird error where it would only retain MDPI & Frontiers if using group_by(), but this works
target_publishers <- unique(SI_TATdata_shiny1$publisher)

# loop through, with print statements by publisher so you know it's working
for (publisher in target_publishers) {
  cat("Processing publisher:", publisher, "\n")
  
  # Filter the data for the current publisher
  publisher_data <- SI_TATdata_shiny1 %>%
    filter(publisher == !!publisher)
  
  # Group by year, journal, and publisher
  summarised_data <- publisher_data %>%
    group_by(year, journal, publisher) %>%
    summarise(
      m = if (all(!is.na(lag) & is.numeric(lag))) mean(lag, na.rm = TRUE) else NA_real_,
      diffsem = sd(lag, na.rm = TRUE) / sqrt(sum(!is.na(lag) & is.numeric(lag))),
      cil = m - 2 * diffsem,
      cih = m + 2 * diffsem,
      label = round(last(m))
    )
  
  # Append the results to the main dataframe
  SI_TATdata_shiny2 <- bind_rows(SI_TATdata_shiny2, summarised_data)
  
  cat("Finished processing publisher:", publisher, "\n\n")
}

# Optional: Ungroup if needed
SI_TATdata_shiny2 <- SI_TATdata_shiny2 %>% ungroup()


# Sanity checks
head(SI_TATdata_shiny2)
unique(SI_TATdata_shiny2$publisher)
colnames(SI_TATdata_shiny2)
# unique(SI_TATdata_shiny2$journal)

## save data to right place

SI_TATdata_shiny2 %>% 
  write_csv("Shiny_app/Data/shiny_SI_TAT_data.csv")
