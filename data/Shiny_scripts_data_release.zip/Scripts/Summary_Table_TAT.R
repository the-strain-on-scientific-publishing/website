###
### The Strain on Scientific Publishing - Summary_Table_TAT.R
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description:
### Save the mean TATs in 2016 and 2022 as well as the rate of change thereof for the final table
###
###

## overall
TAT_overall <- TAT %>% 
  group_by(year) %>% 
  summarise(mlag = mean(lag), sdlag = sd(lag)) %>% 
  filter(year == "2016" | year == "2022") %>% 
  pivot_wider(names_from = year, values_from = c(mlag, sdlag), names_prefix = "TAT_") %>% 
  mutate(publisher = "Overall") %>% 
  select(publisher, everything())

## by publisher
TAT_by_pubisher <- TAT %>% 
  group_by(year, publisher) %>% 
  summarise(mlag = mean(lag), sdlag = sd(lag)) %>% 
  filter(year == "2016" | year == "2022") %>% 
  pivot_wider(names_from = year, values_from = c(mlag, sdlag), names_prefix = "TAT_") %>% 
  select(publisher, everything())

## save
summary_table_TAT <- bind_rows(TAT_overall, TAT_by_pubisher)

## cleanup
rm(TAT_overall, TAT_by_pubisher)
