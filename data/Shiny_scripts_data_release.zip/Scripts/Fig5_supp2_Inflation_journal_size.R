###
### The Strain on Scientific Publishing - Fig5_supp2_Inflation_journal_size.R
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description: 
###
### Generates figure 5supp2 -- impact inflation by journal size
###
###
###


## Impact inflation by journal size

size <- df %>% 
  filter(year == 2022) %>% 
  mutate(class = case_when(Ndocs <= 52 ~ "Small (<1 paper/week)",
                           Ndocs > 52 & Ndocs <= 365 ~ "Medium (<1 paper/day)",
                           Ndocs > 365 & Ndocs <= 3650 ~ "Large (<10 paper/day)",
                           Ndocs > 3650 ~ "Mega (>10 paper/day)")) %>% 
  dplyr::select(journal, class) %>% 
  distinct() %>% 
  mutate(class = as.factor(class), 
         class = fct_relevel(class, "Small (<1 paper/week)", "Medium (<1 paper/day)", "Large (<10 paper/day)"))


## for this analysis, PLOS is dropped because PLOS has very few journals (8 total), so PLOS per category is based on very few journals

df_inf_size <- df %>%
  left_join(size, by = "journal") %>%
  filter(publisher %in% c(subset_publishers))
df_inf_size %>%
  mutate(inflation = cit_per_doc_2/SJR) %>%
  filter(!is.na(class)) %>%
  group_by(year, publisher, class) %>%
  summarise(inflation = mean(inflation, na.rm = T)) %>%
  ggplot(aes(year, inflation, color = publisher))+
  geom_line(size = 1.3)+
  facet_grid(class~., scales = "free")+
  scale_color_manual(values = publisher_color_mapping, name = "") +
  labs(title = "Impact inflation by journal size 1999-2022",
       subtitle = "Cites/Doc (2 years) over SJR",
       y = "Impact Inflation",
       x = "",
       caption = "Source: Scimago website data")  +
  theme(panel.grid.minor.y = element_blank(),
        plot.title.position = "plot",
        axis.text.y = element_text(hjust = 0.5, size=16), 
        panel.grid.major.x = element_blank(),
        strip.text = element_text(size = 11, margin = margin(r = 0)),
        axis.title.y = element_text(size = 18),
        axis.title.x = element_text(size = 18),
        axis.text.x = element_text(size = 16), 
        legend.text = element_text(size = 14),
        legend.title = element_text(size = 14), 
        plot.title = element_text(size = 24), 
        legend.position = "bottom")

ggsave("Figures/Supplemental/Fig5_supp2_IF_inflation_by_journal_size.png", height = 20/1.1, width = 9/1.1, units = "in", dpi = 300)
