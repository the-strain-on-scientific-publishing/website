###
### The Strain on Scientific Publishing - Fig1_supp_OECD.R
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description:
### produces supplement figures to Figure 1
###
###
###

## Fig1supp1A supplement: OECD countries make up the majority of global PhDs awarded, but ignore major countries with growing academic industries such as China and India.
# The following analysis uses external data and estimates for China and India and merges these with the OECD country data to ensure the trend is robust with the inclusion of these countries.
# Total article data are available through Scimago up to 2022, however total PhD data were only available up to 2020 at the time of writing (or 2018 for India).
# We therefore additionally estimated total PhDs in 2021 and 2022 using a quadratic regression, and include these estimates.

# China data from Zwetsloot et al. (2021): https://cset.georgetown.edu/wp-content/uploads/China-is-Fast-Outpacing-U.S.-STEM-PhD-Growth.pdf
# India data from NSF, NSB, Higher Education in Science and Engineering: https://ncses.nsf.gov/pubs/nsb20223/figure/HED-29
# for india, a linear trendline was extrapolated from 2011-2018 data to avoid the need to nest quadratic regression estimates: y = 0.000435746922234881x + 2006.75133035536

## First: generate projected numbers for 2019-2021 for India
IndiaYear = c(2011,2012,2013,2014,2015,2016,2017,2018)
IndiaPhDs = c(14191,15132,15500,13616,15780,17905,23246,26890)
df_india_test<-data.frame(
  year = IndiaYear,
  value = IndiaPhDs)
coefficients<-coef(lm(year~value, data=df_india_test))
trendline_equation <- paste0("y = ", coefficients[2], "x + ", coefficients[1])
#print(trendline_equation) # "y = 0.000435746922234881x + 2006.75133035536"

model <- lm(value ~ year, data = df_india_test)
estimated_value <- predict(model, newdata = data.frame(year = 2019)) # Estimate the value for the year 2019
#print(estimated_value) # Print the estimated value for 2019: 25220.46
model <- lm(value ~ year, data = df_india_test)

estimated_value <- predict(model, newdata = data.frame(year = 2020)) # Estimate the value for the year 2020
#print(estimated_value) # Print the estimated value for 2020: 26873.35
model <- lm(value ~ year, data = df_india_test)

df_chinaPhDs<-data.frame(
  year = c(2013,2014,2015,2016,2017,2018,2019,2020),
  Value = c(39390,40298,40963,42312,44921,47325,49498,51261), # note: 2020 = projected numbers by study
  country = "China"
)

df_IndiaPhDs<-data.frame(
  year = c(2013,2014,2015,2016,2017,2018,2019,2020),
  Value = c(15500,13616,15780,17905,23246,26890,25220,26873), # note: 2019-2020 are projected numbers by me
  country = "India"
)

new_df_phds<-rbind(df_chinaPhDs[, c("year", "country", "Value")],
                   df_IndiaPhDs[, c("year", "country", "Value")])
#new_df_phds
stacked_df <- bind_rows(OECD_data[, c("year", "country", "Value")], new_df_phds)
OECD_data<-stacked_df

## Filter the PhDs for only sciences (non-arts/humanities)

### before anything: growth in number of articles, overall
TotalDocs <- df %>%
  mutate(year = as.numeric(year)) %>%
  group_by(year) %>%
  summarise(N = sum(Ndocs)) %>%
  ungroup()

TotalPhDs <- OECD_data %>%
  mutate(year = as.numeric(year)) %>%
  mutate(value = as.numeric(Value)) %>%
  group_by(year) %>%
  summarise(PhDs = sum(value, na.rm = TRUE)) %>%
  ungroup()

combined_df<-merge(TotalDocs,TotalPhDs, by = "year", all = TRUE)
combined_df <- combined_df %>%
  filter(year >= 2013 & year <= 2022)


corrected_df<-combined_df

# Fit the quadratic linear model using the data from 2013 to 2020
model <- lm(PhDs ~ year + I(year^2), data = corrected_df)
# Create a new dataframe for 2021 and 2022
new_years <- data.frame(year = c(2021, 2022))
# Predict the number of PhDs for 2021 and 2022 along with confidence intervals
predicted_phds <- predict(model, newdata = new_years, interval = "confidence", level = 0.95)
# Print the predicted values and confidence intervals
#print(predicted_phds)
# fit      lwr      upr
# 1 333162.4 316326.9 349997.9
# 2 323564.6 297780.6 349348.7
# replace 2021 and 2022 with the values interpolated from quadratic expression
corrected_df$PhDs[corrected_df$year == 2021] <- NA 
corrected_df$PhDs[corrected_df$year == 2022] <- NA
corrected_df$PhDs2[corrected_df$year == 2020] <- corrected_df$PhDs[corrected_df$year == 2020]
corrected_df$PhDs2[corrected_df$year == 2021] <- predicted_phds[1]
corrected_df$PhDs2[corrected_df$year == 2022] <- predicted_phds[2]
corrected_df


## Figure 1 supp 1 A: Adding China and India PhDs with OECD data 

scaleFactor <- (max(corrected_df$N) / max(corrected_df$PhDs,na.rm=T))*.85

Fig1supp1A<-ggplot(corrected_df, aes(x = year)) +
  geom_line(aes(y = N), col = "black", linewidth = 1.5) +
  geom_line(aes(y = PhDs * scaleFactor), col = "red", na.rm = TRUE, linewidth = 1.5, linetype = "dashed") +
  geom_line(aes(y = PhDs2 * scaleFactor), col = "red", na.rm = TRUE, linewidth = 1, linetype = "dotted", alpha = 0.5) +
  scale_y_continuous(name = "Total articles",
                     labels = millions_format,
                     sec.axis = sec_axis(~ . / scaleFactor, name = "PhDs added in OECD + China + India",labels = comma_format()),
                     limits = c(1700000, 3000000),
                     breaks = seq(1800000, 3000000, by = 400000)) +  # Set limits for the left y-axis
  scale_x_continuous(breaks = seq(2013, 2022, by = 3)) +
  theme(
    axis.title.y.left = element_text(color = "black", size = 18),
    axis.text.y.left = element_text(color = "black", margin = margin(r = 3), size = 16),
    axis.text.y.right = element_text(color = "red", size = 16),
    axis.title.y.right = element_text(color = "red", angle = 270, hjust = 0, vjust = 1.5, size = 18),
    axis.text.x = element_text(size = 16),
    panel.grid.major = element_blank(),
    panel.grid.minor = element_blank(),
    axis.ticks.y.left = element_line(),
    axis.ticks.y.right = element_line(color="red"),
    plot.margin = margin(t = 1, r = 1, b = 1, l = 1, unit = "cm")
  )+
  labs(title = "Newly published papers and total PhDs in OECD countries + China + India",
       subtitle = "New papers and PhDs per year (2021,2022 PhDs = projections)",
       caption = "Source: Total articles -- Scimago website data; N PhDs - OECD, Zwetsloot et al. (2021), NSF/NSB", 
       x = "")

## saving 
ggsave(plot = Fig1supp1A, "Figures/Building blocks/Fig1supp1A_india_china_too_w_projections_to_2022.png",
       width = 12/1, height = 9/1, units = "in", dpi = 300)


corrected_df$ratio <- corrected_df$N/corrected_df$PhDs
corrected_df$ratio2 <- corrected_df$N/corrected_df$PhDs2

corrected_df

## Figure 1 supp 1 B: trend of nDocs/Phd including China and India

Fig1supp1B <- corrected_df %>% 
  ggplot(aes(x = year)) +
  # Total articles
  geom_line(aes(y = ratio), col = "black", linewidth = 1.5, na.rm = TRUE) +
  geom_line(aes(y = ratio2), col = "black", linetype = "dotted", linewidth = 1, na.rm = TRUE) +
  scale_y_continuous(name = "Ndocs / PhDs (OECD + China + India)")+
  scale_x_continuous(breaks = seq(2013, 2022, by = 3))+
  labs(title = "Ratio total articles to PhD graduates in OECD countries + China + India", 
       subtitle = "How has the ratio of total articles:PhDs awarded changed over time? Dotted line = projected numbers",
       caption = "Source: Total articles -- Scimago website data; N PhDs - OECD, Zwetsloot et al. (2021), NSF/NSB", 
       x = "")+
  theme(
    axis.title.y = element_text(color = "black", size = 18),
    axis.text.y = element_text(color = "black", margin = margin(r = 3), size = 16),
    axis.text.x = element_text(size = 16)
  )

ggsave(plot = Fig1supp1B, "Figures/Building blocks/Fig1supp1B_ratio_india_china_too_projected_to_2022.png", 
       width = 12/1.2, height = 9/1.2, units = "in", dpi = 300)

### using patchwork create Fig1 supp1 panels A and B

Figure1supp1 <- (Fig1supp1A + Fig1supp1B)
Figure1supp1 + plot_annotation(tag_levels = list(c('A','B'))) &
  theme(plot.tag = element_text(size = 36)) 
ggsave("Figures/Building blocks/Fig1supp1-1_patchwork.png", 
       width = 22, height = 8, units = "in", dpi = "retina")