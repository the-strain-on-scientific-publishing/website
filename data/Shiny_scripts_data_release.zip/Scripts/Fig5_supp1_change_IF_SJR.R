###
### The Strain on Scientific Publishing - Fig5_supp1_change_IF_SJR.R
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description: 
### Generates figure 5supp1 -- IF and SJR changes over time for selected publishers
###
###

## Return to original dataframe from N_papers_and_PhDs.R (avoids renaming everything in scripts)

df <- read_csv("Data/Scimago_data_filtered.csv") 
ID <- read_csv("Data/sjr_ID_to_publisher.csv") 

df <- df %>% 
  left_join(ID, by = join_by(journal, publisher))
rm(ID)

df$inflation <- df$cit_per_doc_2/df$SJR

df <- clean_publisher_names(df)

##### 1. Prepare data #######

## subset of publishers considered

subset_publishers <- c(
  "MDPI",
  "Springer", # Note this does not include Nature at the moment
  "Elsevier",
  "Frontiers",
  "Wiley",
  "PLOS",
  "BMC",
  "Hindawi",
  "Taylor & Francis",
  "Nature"
)


######

dfplot <- df %>% 
  filter(publisher %in% subset_publishers) %>% 
  filter(year >= 2013 & year <= 2022)

## IF over time by proxy using Scimago Cites/Doc (2 years)

Fig5supp1A<-dfplot %>% 
  group_by(publisher, year) %>% 
  summarise(N = mean(cit_per_doc_2, na.rm=TRUE)) %>% 
  ggplot(aes(year, N, color = publisher))+
  geom_line(linewidth =1.3)+
  scale_y_continuous(labels = scales::label_number(scale_cut = cut_short_scale())) +
  gghighlight::gghighlight(publisher %in% c("MDPI", "Elsevier", 
                                            "Frontiers",
                                            "Springer",
                                            "Hindawi", "PLOS",
                                            "Wiley", "Nature",
                                            "Taylor & Francis", "BMC"), 
                           label_params = list(direction = "y", nudge_x = 2, hjust = 1, size = 6), 
                           use_group_by = F, label_key = publisher)+
  scale_x_continuous(breaks = seq(2013, 2022, by = 3))+
  scale_color_manual(values = publisher_color_mapping) +
  labs(title = "Change in Scimago Cites/Doc (2years)",
       y = "Cites/Doc (2 years) - proxy of IF",
       x = "", 
       caption = "Source: Scimago website data")+
  theme(panel.grid.minor.y = element_blank(),
        legend.position = "bottom",
        plot.title.position = "plot",
        axis.text.y = element_text(hjust = 0.5, size=16), 
        panel.grid.major.x = element_blank(),
        axis.title.y = element_text(size = 18),
        axis.title.x = element_text(size = 18),
        axis.text.x = element_text(size = 16), 
        legend.text = element_text(size = 14),
        legend.title = element_text(size = 14),
        plot.title = element_text(size = 24))
Fig5supp1A
ggsave("Figures/Building blocks/Fig5_supp1_IF_growth_by_publisher.png",
       height = 9/1.1, width = 12/1.1, units = "in", dpi = 300)

## SJR over time

Fig5supp1B<-dfplot %>% 
  group_by(publisher, year) %>% 
  summarise(N = mean(SJR, na.rm=TRUE)) %>% 
  ggplot(aes(year, N, color = publisher))+
  geom_line(linewidth =1.3)+
  scale_y_continuous(labels = scales::label_number(scale_cut = cut_short_scale())) +
  gghighlight::gghighlight(publisher %in% c("MDPI", "Elsevier", 
                                            "Frontiers",
                                            "Springer",
                                            "Hindawi", "PLOS",
                                            "Wiley", "Nature",
                                            "Taylor & Francis", "BMC"), 
                           label_params = list(direction = "y", nudge_x = 2, hjust = 1, size = 6), 
                           use_group_by = F, label_key = publisher)+
  scale_x_continuous(breaks = seq(2013, 2022, by = 3))+
  #scale_color_brewer(palette = "Set1")+
  scale_color_manual(values = publisher_color_mapping) +
  labs(title = "Change in SJR per publisher",
       y = "Scimago Journal Rank (SJR)",
       x = "", 
       caption = "Source: Scimago website data")+
  theme(panel.grid.minor.y = element_blank(),
        legend.position = "bottom",
        plot.title.position = "plot",
        axis.text.y = element_text(hjust = 0.5, size=16), 
        panel.grid.major.x = element_blank(),
        axis.title.y = element_text(size = 18),
        axis.title.x = element_text(size = 18),
        axis.text.x = element_text(size = 16), 
        legend.text = element_text(size = 14),
        legend.title = element_text(size = 14), 
        plot.title = element_text(size = 24))
Fig5supp1B
ggsave("Figures/Building blocks/Fig5_supp2_SJR_change_by_publisher.png",
       height = 9/1.1, width = 12/1.1, units = "in", dpi = 300)


# Figure 5supp1n2
Figure5supp1 <- (Fig5supp1A / Fig5supp1B)
Figure5supp1 + plot_annotation(tag_levels = 'A') &
  theme(plot.tag = element_text(size = 36))
ggsave("Figures/Supplemental/Fig5_supp1_IF_and_SJR_growth.png", 
       width = 15, height = 20, units = "in", dpi = "retina")
