###
### The Strain on Scientific Publishing - Fig5_supp4B_IFvsCitPerDoc_2022.R
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description: 
### Generates figure 5supp4 -- comparison of Cites per Doc (Scimago) to Impact Factor (Clarivate)
###
###
###


## Return to original dataframe from N_papers_and_PhDs.R (avoids renaming everything in scripts)

df <- read_csv("Data/Scimago_data_filtered.csv") 
ID <- read_csv("Data/sjr_ID_to_publisher.csv") 

df <- df %>% 
  left_join(ID, by = join_by(journal, publisher))
rm(ID)

df$inflation <- df$cit_per_doc_2/df$SJR

df <- clean_publisher_names(df)


##### 1. Prepare data #######

## subset of publishers considered

subset_publishers <- c(
  "MDPI",
  "Nature",
  "Springer",
  "Elsevier",
  "Frontiers",
  "Wiley",
  "PLOS",
  "BMC",
  "Hindawi",
  "Taylor & Francis"
)

# Include IFs from collection available, while also creating good column names for data merging
df_IF <- read_csv("Data/IF_historical_merged.csv")

unique(df_IF$Publisher)

names(df_IF) <- c("title", "publisher", "ISSN", "eISSN", "2022", "2021", "2020", "2019", "2018", "2017", "2016", "2015", "2014", "2013", "2012")
df_IF <- df_IF %>%
  gather(key = "year", value = "IF", `2022`, `2021`, `2020`, `2019`, `2018`, `2017`, `2016`, `2015`, `2014`, `2013`, `2012`, na.rm = TRUE)

df_IF$year <- as.integer(df_IF$year)
df_IF$IF <- as.numeric(df_IF$IF)

df_IF$ISSN <- gsub("-", "", df_IF$ISSN)
df_IF$eISSN <- gsub("-", "", df_IF$eISSN)

df_IF <- df_IF %>%
  dplyr::select(title, year, IF)

# Perform the left join with the modified df_IF using issn and eISSN
df <- df %>%
  left_join(df_IF, by = c("title", "year")) 
## issues with the formatting of ISSN and eISSN prevent a robust coalesce or left_join, however journal titles are unique, and recover accurate mapping

df$IF_inflation <- df$IF/df$SJR

summary(na.omit(df$IF_inflation))
df <- df %>%
  filter(year == 2022)
## there is a decoupling of journals indexed by Scopus and Clarivate after Clarivate delisted many journals in its 2023 JCR, 
## and so here we look at only the historical correlation

# Linear model

lm_df<-lm(cit_per_doc_2~IF, data = na.omit(df))
summary(lm_df)

# plot
CITESvsIF_plot<-ggplot(df, aes(x=cit_per_doc_2, y=IF)) +
  geom_point(shape=1) +    # Use hollow circles
  geom_smooth(method=lm) +   # Add linear regression line 
  scale_y_log10() +
  scale_x_log10() +
  #geom_text(aes(color=Publisher.y, label=Title, size=IF)) +
  #scale_size(range=c(1.9,2)) +
  labs(x = "Scimago Cites / Doc (2 years)",
       y = "Clarivate Impact Factor",
       title = "Comparison of Scimago Cites/Doc (2 years) to Clarivate journal IF",
       subtitle = "lm()
       Residual standard error: 1.716 on 2749 degrees of freedom, Multiple R-squared:  0.7241,
       Adjusted R-squared:  0.7240, F-statistic: 7216 on 1 and 2749 DF,  p-value: < 2.2e-16")
CITESvsIF_plot
ggsave(plot = CITESvsIF_plot, 
       "Figures/Building blocks/Fig5_supp4a2_IFvsCitesPerDoc2yr_2022.png", 
       height = 9/1.2, width = 12/1.2, units = "in", dpi = 300)

############################################
### STATISTICS Fig5a_IF_2022
############################################

## prepare data as 2022 only:
## no zero values for inflation (which would indicate a journal that received an SJR, yet somehow had no citations that year -> censored from dataset)

dfTK<-df %>%
  filter(IF_inflation > 0 & IF_inflation < 30,
         year == 2022,
         publisher %in% subset_publishers)

# Data transformations as in Fig5_inflation.R and Fig5_selfcites.R descriptions

dfTK$inv_IF_inflation <- 1/dfTK$IF_inflation 
dfTK$sqrtinv_IF_inflation <- sqrt(dfTK$IF_inflation) 
dfTK$publisher <- as.factor(dfTK$publisher)
head(dfTK)

# ANOVAs

res.aov <- aov(IF_inflation ~ publisher, data = dfTK)
summary(res.aov)

res.aov.sqrtinv <- aov(sqrtinv_IF_inflation ~ publisher, data = dfTK)
summary(res.aov.sqrtinv)

# # QQplots
# 
# plot(res.aov, 1, cex=0.2)
# plot(res.aov, 2,cex=0.2)
# 
# plot(res.aov.sqrtinv, 1, cex=0.2)
# plot(res.aov.sqrtinv, 2,cex=0.2) # the double transformation of inverse and square root does a fantastic job of normalising the data's distribution

# Multiple comparisons (both raw data and transformed data)

TK<-TukeyHSD(res.aov)
TK
TK_data<-as.data.frame(TK[1]) 
write.csv(TK_data, 'Tables/IF_ImpactInflation_2022_TukeyHSD.csv')

TK_data<-as.data.frame(TK[1])
TK <- emmeans(res.aov, "publisher")
# Generate letter-based grouping for multiple comparisons
letter_groups <- cld(TK, Letters = letters)
letter_groups 
write.csv(letter_groups, 'Tables/IF_ImpactInflation_2022_TukeyHSD_lettergroups.csv')

TK<-TukeyHSD(res.aov.sqrtinv)
TK
TK_data<-as.data.frame(TK[1]) 
write.csv(TK_data, 'Tables/IF_ImpactInflation_2022_sqrtinv_TukeyHSD.csv')

TK_data<-as.data.frame(TK[1])
TK <- emmeans(res.aov.sqrtinv, "publisher")
# Generate letter-based grouping for multiple comparisons
letter_groups <- cld(TK, Letters = letters)
letter_groups
write.csv(letter_groups, 'Tables/IF_ImpactInflation_2022_sqrtinv_TukeyHSD_lettergroups.csv')

## add letter groups to plot

# Merge the letter_groups and meaninf data
merged_data <- merge(letter_groups, df, by = "publisher")
head(merged_data)

# Assuming merged_data contains the merged letter_groups and meaninf data
merged_data <- merged_data %>%
  filter(year == 2022) %>%
  filter(publisher %in% subset_publishers) %>%
  group_by(year, publisher) %>%
  mutate(meaninf = mean(IF_inflation, na.rm = TRUE))
merged_data <- merged_data %>%
  mutate(.group = trimws(.group))


IF_Inflation_2022 <- ggplot(merged_data, aes(IF_inflation, reorder(publisher, meaninf))) +
  geom_jitter(aes(fill = publisher), height = 0.4, width = 0, size = 2,
              alpha = 0.1, shape = 21, color = "grey50") +
  geom_violin(alpha = 0.1, adjust = 1.5) +
  geom_boxplot(width = 0.1, alpha = 0.1) +
  geom_text(aes(x = 12, label = merged_data$.group), 
            hjust = 0, size = 4, color = "blue") +  # Adjust the hjust value to change the horizontal position of the text
  scale_fill_manual(values = sapply(df$publisher, get_publisher_color)) +
  theme(legend.position = "none",
        plot.caption = element_text(size = 13)) +
  scale_x_continuous(breaks = seq(0,12.5, by = 3), limits = c(0, 12.5)) +
  labs(
    title = "Impact inflation, 2022",
    subtitle = "IF over SJR",
    y = "",
    x = "IF inflation",
    caption = "The x-axis is limited at 12.5 to prevent the plot from stretching to show just a few major outliers
    Source: Scimago website data, Clarivate JCR (subset)"
  )
IF_Inflation_2022
ggsave(plot=IF_Inflation_2022, "Figures/Building blocks/Fig5_supp4c_2022_Inflation_Scimago_data.png", 
       height = 12/1.2, width = 12/1.2, units = "in", dpi = 300)
