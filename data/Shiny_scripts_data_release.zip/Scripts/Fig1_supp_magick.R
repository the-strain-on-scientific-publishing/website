###
### The Strain on Scientific Publishing - Fig1_supp_magick.R
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description:
### Stitch together the building blocks to create Figure 1 supp 1
###


### using magick create the final Fig 1 supp 1

image1 <- image_read("Figures/Building blocks/Fig1supp1-1_patchwork.png")
image2 <- image_read("Figures/Building blocks/Fig1supp1-2_patchwork.png")
combined_image <- image_append(c(image1, image2), stack = TRUE)
image_write(combined_image, path = "Figures/Supplemental/Fig1supp1.png") 

