###
### The Strain on Scientific Publishing
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description:
### storing functions that are used in several places in the analyses, 
### to avoid duplication and to allow for easier debugging


#### Matching colours to publishers


# A function to match colours to publishers consistently throughout
get_publisher_color <- function(publisher_name) {
  if (publisher_name %in% list_main_publishers) {
    idx <- match(publisher_name, list_main_publishers)
    publisher_comparison_colors[idx]
  } else {
    "grey"  # Default color for publishers not in the list_main_publishers
  }
}


#### Cleaning SJR publishers ####

# this function just cleans the names of publishers
# lumping together different names by which a unique publisher is known
# eg because of typos, or different languages, or trailing spaces...

clean_publisher_names <- function(df) {
  
  df <- df %>% 
    mutate(publisher = case_when(
      publisher== "Maik Nauka Publishing / Springer SBM"~ "Springer",
      publisher== "Springer Berlin"~ "Springer",
      publisher== "Springer Boston"~ "Springer",
      publisher== "Springer China"~ "Springer",
      publisher== "Springer Fachmedien Wiesbaden GmbH"~ "Springer",
      publisher== "Springer Gabler"~ "Springer",
      publisher== "Springer GmbH &amp, Co, Auslieferungs-Gesellschaf"~ "Springer",
      publisher== "Springer Healthcare"~ "Springer",
      publisher== "Springer Heidelberg"~ "Springer",
      publisher== "Springer India"~ "Springer",
      publisher== "Springer International Publishing AG"~ "Springer",
      publisher== "Springer Japan"~ "Springer",
      publisher== "Springer London"~ "Springer",
      publisher== "Springer Nature"~ "Springer",
      publisher== "Springer Nature Switzerland AG"~ "Springer",
      publisher== "Springer Netherlands"~ "Springer",
      publisher== "Springer New York"~ "Springer",
      publisher== "Springer Paris"~ "Springer",
      publisher== "Springer Publishing Company"~ "Springer",
      publisher== "Springer Science + Business Media"~ "Springer",
      publisher== "Springer Science and Business Media B.V."~ "Springer",
      publisher== "Springer Science and Business Media Deutschland GmbH"~ "Springer",
      publisher== "Springer Singapore"~ "Springer",
      publisher== "Springer US"~ "Springer",
      publisher== "Springer Verlag"~ "Springer",
      publisher== "Springer Vieweg"~ "Springer",
      publisher== "SpringerOpen"~ "Springer",
      publisher== "Springer-Verlag GmbH and Co. KG"~ "Springer",
      publisher== "Springer-Verlag Italia Srl"~ "Springer",
      publisher== "Springer-Verlag Wien"~ "Springer",
      publisher== "Springer Medizin"~ "Springer",
      publisher== "Springer GmbH &amp; Co, Auslieferungs-Gesellschaf"~ "Springer",
      publisher== "Elsevier Ltd."~ "Elsevier",
      publisher== "Elsevier"~ "Elsevier",
      publisher== "Elsevier Inc."~ "Elsevier",
      publisher== "Elsevier BV"~ "Elsevier",
      publisher== "Elsevier USA"~ "Elsevier",
      publisher== "Elsevier Masson s.r.l."~ "Elsevier",
      publisher== "Elsevier Ireland Ltd"~ "Elsevier",
      publisher== "Elsevier Science B.V."~ "Elsevier",
      publisher== "Elsevier Science"~ "Elsevier",
      publisher== "Elsevier Sp. z o.o."~ "Elsevier",
      publisher== "Elsevier GmbH"~ "Elsevier",
      publisher== "Elsevier Espana"~ "Elsevier",
      publisher== "Elsevier Editora Ltda"~ "Elsevier",
      publisher== "Elsevier Doyma"~ "Elsevier",
      publisher== "Elsevier Taiwan LLC"~ "Elsevier",
      publisher== "Elsevier (Singapore) Pte Ltd"~ "Elsevier",
      publisher== "Elsevier Espana S.L.U"~ "Elsevier",
      publisher== "Elsevier Australia"~ "Elsevier",
      publisher== "Elsevier Science &amp; Technology"~ "Elsevier",
      publisher== "Elsevier Saunders"~ "Elsevier",
      publisher== "Elsevier Scientific Publishers Ireland"~ "Elsevier",
      publisher== "John Wiley &amp, Sons Inc."~ "Wiley",
      publisher== "John Wiley &amp; Sons Inc."~ "Wiley",
      publisher== "John Wiley and Sons Inc."~ "Wiley",
      publisher== "John Wiley and Sons Ltd"~ "Wiley",
      publisher== "Wiley - VCH Verlag GmbH &amp, CO. KGaA"~ "Wiley",
      publisher== "Wiley Blackwell"~ "Wiley",
      publisher== "Wiley Subscription Services"~ "Wiley",
      publisher== "Wiley-Blackwell"~ "Wiley",
      publisher== "Wiley-Blackwell for the International Association for the Study of Obesity"~ "Wiley",
      publisher== "Wiley-Blackwell Publishing Ltd"~ "Wiley",
      publisher== "Wiley-Liss Inc."~ "Wiley",
      publisher== "Wiley-VCH Verlag"~ "Wiley",
      publisher== "Blackwell"~ "Wiley",
      publisher== "Blackwell Munksgaard"~ "Wiley",
      publisher== "Blackwell Publishing"~ "Wiley",
      publisher== "Blackwell Publishing Asia"~ "Wiley",
      publisher== "Blackwell Publishing Asia Pty Ltd"~ "Wiley",
      publisher== "Basil Blackwell"~ "Wiley",
      publisher== "Wiley - VCH Verlag GmbH &amp; CO. KGaA"~ "Wiley",
      publisher== "Routledge, Taylor &amp; Francis Group"~ "Taylor & Francis",
      publisher== "Taylor & Francis"~ "Taylor & Francis",
      publisher== "Taylor and Francis AS"~ "Taylor & Francis",
      publisher== "Taylor and Francis Inc."~ "Taylor & Francis",
      publisher== "Taylor and Francis Ltd."~ "Taylor & Francis",
      publisher== "Institute of Electrical and Electronics Engineers Inc."~ "IEEE",
      publisher== "IEEE Advancing Technology for Humanity"~ "IEEE",
      publisher== "IEEE Canada"~ "IEEE",
      publisher== "IEEE Circuits and Systems Society"~ "IEEE",
      publisher== "IEEE Communications Society"~ "IEEE",
      publisher== "IEEE Computational Intelligence Society"~ "IEEE",
      publisher== "IEEE Computer Society"~ "IEEE",
      publisher== "IEEE Education Society"~ "IEEE",
      publisher== "IEEE Electron Devices Society"~ "IEEE",
      publisher== "IEEE Geosciene and Remote Sensing Society"~ "IEEE",
      publisher== "IEEE Systems, Man, and Cybernetics Society"~ "IEEE",
      publisher== "IGI Global Publishing"~ "IGI Global",
      publisher== "IGI Publishing"~ "IGI Global",
      publisher== "Multidisciplinary Digital Publishing Institute (MDPI)"~ "MDPI",
      publisher== "MDPI AG"~ "MDPI",
      publisher== "Hindawi Publishing Corporation"~ "Hindawi",
      publisher== "Hindawi Limited"~ "Hindawi",
      # publisher== "Wiley-Hindawi"~ "Hindawi", # unclear which to attribute to
      publisher== "Nature Partner Journals"~ "Nature",
      publisher== "Nature Publishing Group"~ "Nature",
      publisher== "Bentham Science Publishers"~ "Bentham Science",
      publisher== "Bentham Science Publishers B.V."~ "Bentham Science",
      publisher== "SAGE Publications Inc."~ "SAGE",
      publisher== "SAGE Publications Ltd"~ "SAGE",
      publisher== "Sage Publications"~ "SAGE",
      publisher== "Sage Publications India Pvt. Ltd"~ "SAGE",
      publisher== "Sage Periodicals Press"~ "SAGE",
      publisher== "SAGE-Hindawi Access to Research"~ "SAGE",
      publisher== "Walter de Gruyter GmbH"~ "De Gruyter",
      publisher== "De Gruyter Open Ltd."~ "De Gruyter",
      publisher== "De Gruyter Mouton"~ "De Gruyter",
      publisher== "de Gruyter"~ "De Gruyter",
      publisher== "Walter de Gruyter"~ "De Gruyter",
      publisher== "Walter de Gruyter GmbH &amp, Co. KG"~ "De Gruyter",
      publisher== "De Gruyter Oldenbourg"~ "De Gruyter",
      publisher== "Wolters Kluwer Medknow Publications"~ "Wolters Kluwer",
      publisher== "Wolters Kluwer Health"~ "Wolters Kluwer",
      publisher== "Wolters Kluwer (UK) Ltd."~ "Wolters Kluwer",
      publisher== "Lippincott Williams and Wilkins Ltd."~ "Lippincott",
      publisher== "Lippincott Williams and Wilkins"~ "Lippincott",
      publisher== "Rubber Division of the American Chemical Society"~ "American Chemical Society",
      publisher== "Brunner - Routledge (US)"~ "Routledge",
      publisher== "Institute of Physics Publishing"~ "IOP Publishing Ltd.",
      publisher == "Frontiers Media S.A." ~ "Frontiers",
      publisher == "BioMed Central Ltd." ~ "BMC", 
      publisher == "American Chemical Society" ~ "ACS", 
      publisher == "Association for Computing Machinery (ACM)" ~ "ACM", 
      publisher == "American Institute of Aeronautics and Astronautics Inc. (AIAA)" ~ "AIAA",
      publisher == "Oxford University Press" ~ "Oxford UP", 
      publisher == "Public Library of Science" ~ "PLOS",
      TRUE ~ publisher))
  
  df
  
}

#### Plot label formatting ####

# a function to transform left y-axis labels into per million (m)
millions_format <- function(x) {
  paste0(format(x/1000000, nsmall = 1), "m")
}

# a function to transform left y-axis labels into per thousand (k)
thousands_format <- function(x) {
  paste0(format(x/1000), "k")
}

#### Cleaning scrape publishers ####

# this function just cleans the publishers name for display in SI/TAT plots

clean_scrape_publishers <- function(df) {
  
  df <- df %>% 
    mutate(publisher = case_when(publisher == "bmc" ~ "BMC", 
                                 publisher == "frontiers" ~ "Frontiers", 
                                 publisher == "hindawi" ~ "Hindawi",
                                 publisher == "mdpi" ~ "MDPI",
                                 publisher == "nature" ~ "Nature",
                                 publisher == "plos" ~ "PLOS",
                                 publisher == "springer" ~ "Springer",
                                 publisher == "wiley" ~ "Wiley",
                                 TRUE ~ publisher))
  df
}
