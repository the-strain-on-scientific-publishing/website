###
### The Strain on Scientific Publishing - Summary_Table_IFI.R
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description:
### Save the IF inflation data we have for the final table
###
###



## overall

summary_IFI_overall <- df %>% 
  filter(year == 2016 | year == 2022) %>%
  group_by(year) %>% 
  summarise(IFI = mean(inflation, na.rm = T)) %>% 
  pivot_wider(names_from = year, values_from = IFI, names_prefix = "IFI_") %>% 
  mutate(publisher = "Overall") %>% 
  select(publisher, everything())

## by publisher
summary_IFI_pub <- df %>% 
  filter(year == 2016 | year == 2022) %>%
  filter(publisher %in% main_publishers) %>% 
  mutate(publisher = if_else(publisher == "PLoS", "PLOS", publisher)) %>% 
  group_by(year, publisher) %>% 
  summarise(IFI = mean(inflation, na.rm = T)) %>% 
  pivot_wider(names_from = year, values_from = IFI, names_prefix = "IFI_") 

## saving
summary_table_IFI <- bind_rows(summary_IFI_overall, summary_IFI_pub)

## cleanup
rm(summary_IFI_overall, summary_IFI_pub)
