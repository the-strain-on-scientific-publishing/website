###
### The Strain on Scientific Publishing
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description:
### 2022 rejection rates analysis
###
###


### GLM results for 2022 rejection rates, journals 10 years younger or less

PGB_2022_Rejection_rates <- read_csv("Data/reject_rates_subfiles/PGB_2022_Rejection_rates.csv")%>%
  mutate(journal_age=2023-first_year)%>%
  filter(publisher!="PLOS")%>%
  filter(journal_age<=10)


# Elsevier ----------------------------------------------------------------

Elsevier_RR<-PGB_2022_Rejection_rates%>%
  filter(publisher=="Elsevier")

model<-glm(data=Elsevier_RR,formula = RR~SJR*Ndocs*journal_age*cit_per_doc_2)

graph1<-plot_model(model,vline.color = "black")+
  theme_classic()+
  labs(title="Elsevier",y="")

# Hindawi ----------------------------------------------------------------

Hindawi_RR<-PGB_2022_Rejection_rates%>%
  filter(publisher=="Hindawi")

model<-glm(data=Hindawi_RR,formula =RR~SJR*Ndocs*journal_age*cit_per_doc_2)

graph2<-plot_model(model,vline.color = "black")+
  theme_classic()+
  labs(title="Hindawi",y="")+
  theme(axis.text.y=element_blank())

# MDPI ----------------------------------------------------------------

MDPI_RR<-PGB_2022_Rejection_rates%>%
  filter(publisher=="MDPI")

model<-glm(data=MDPI_RR,formula = RR~SJR*Ndocs*journal_age*cit_per_doc_2)

graph3<-plot_model(model,vline.color = "black")+
  theme_classic()+
  labs(title="MDPI",y="")+
  theme(axis.text.y=element_blank())

# T&F ----------------------------------------------------------------

Taylor_RR<-PGB_2022_Rejection_rates%>%
  filter(publisher=="Taylor&Francis")

model<-glm(data=Taylor_RR,formula = RR~SJR*Ndocs*journal_age*cit_per_doc_2)
summary(model)
graph4<-plot_model(model,vline.color = "black")+
  theme_classic()+
  labs(title="Taylor & Francis",y="")+
  theme(axis.text.y=element_blank())


### plotting

axis_title <- ggplot(data.frame(x = c(0, 1)), aes(x = x)) + geom_blank() +
  theme_void() + 
  theme(axis.title.x = element_text()) + 
  labs(x = "Estimate")

(graph1|graph2|graph3|graph4)/axis_title+
  plot_layout(heights = c(40, 1))+
  plot_annotation(title = 'General Linear Models - 2022 Rejection Rates & Journals <= 10 years old')
 

ggsave("Figures/Building blocks/RR_2022_glm_analysis.png",dpi="retina")


