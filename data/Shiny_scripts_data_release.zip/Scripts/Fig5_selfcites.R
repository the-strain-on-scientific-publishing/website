###
### The Strain on Scientific Publishing - Fig5_selfcites.R
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description: 
### Generates figure 5B -- self-citation data for selected publishers
###
###
###

## Import a new dataset to analyse self-citations, because this data had to be scraped from the Scimago website

## Return to original dataframefrom N_papers_and_PhDs.R (avoids renaming everything in scripts)

df_sc <- read_csv("Data/sjr_scraped_dataset.csv") 
ID <- read_csv("Data/sjr_ID_to_publisher.csv") 

df_sc <- df_sc %>% 
  left_join(ID, by = join_by(journal))
rm(ID)

df_sc$inflation <- df_sc$cit_per_doc_2/df_sc$SJR

df_sc <- clean_publisher_names(df_sc)

##### 1. Prepare data #######

## subset of publishers considered

subset_publishers <- c(
  "MDPI",
  "Nature",
  "Springer",
  "Elsevier",
  "Frontiers",
  "Wiley",
  "PLOS",
  "BMC",
  "Hindawi",
  "Taylor & Francis"
)



############################################
# Fig5b
############################################

## Fig5b, within-journal self-citation rate

self_cite_2022<- df_sc %>% 
  filter(year == 2022) %>% 
  mutate(share_self_cite = share_self_cite) %>%
  filter(publisher %in% subset_publishers) %>%
  filter(total_cites > 1000) %>%
  group_by(publisher) %>% 
  ggplot(aes(share_self_cite, reorder(publisher,share_self_cite)))+
  geom_jitter(aes(fill = publisher), height = 0.4, width = 0, size = 2,
              alpha = 0.1, shape = 21, color = "grey50")+
  geom_violin(alpha = 0.1, adjust = 1.5)+
  geom_boxplot(width=0.1, alpha = 0.1)+
  scale_fill_manual(values = sapply(df$publisher, get_publisher_color)) +
  xlim(0, 0.25) + 
  theme(legend.position = "none")+
  labs(title = "Within-journal self citation rate, 2022", 
       subtitle = "Does not include journals citing across each other", 
       y = "",
       x = "Only shows journals with total annual citations > 1000", 
       caption = "Source: Scimago scrape data")
self_cite_2022

## Author note: x-axis (plot only) limited to 10 to avoid stretching to show just a few outliers
## Modify above scale_x_continuous(... limits = c(0,10)) to show full data including outliers 

############################################
## STATISTICS self citation data 2021
############################################

# Filter dataset for only journals with >1000 citations per year, for 2021 specifically as per Fig5A
# Also removed zero values to enable data transformations and test for robustness to extent of data normality
# Journals with zeros/NAs in SJR are removed as infinites and highly unique cases (not indexed in Scimago that year)
# Journals with zeros/NAs in IF are also removed as being highly unique cases (no citations per year, but receives SJR anyways)
# Only >1000 citations per year added as a filter because data aggregated at journal level,
## meaning young journals without many papers to cite can reduce the apparent self-citation rate at the publisher level,
## or niche journals with high rates of self-cite can inflate it instead (but in an academically-justifiable way)

df_sc_over1000<-df_sc %>%
  filter(total_cites > 1000,
         year == 2021,
         share_self_cite>0,
         publisher %in% subset_publishers)

# creating multiple dataframes to test effect of different transformations as data do not have a normal distribution
## ultimately the same sqrtinv treatment is taken, but the following data transformations were attempted and are shown here

df_sc_over1000$natlog_share_self_cite <- log(df_sc_over1000$share_self_cite,) # natural log
df_sc_over1000$log10_share_self_cite <- log(df_sc_over1000$share_self_cite,base=10) # log10
df_sc_over1000$sqrt_share_self_cite <- sqrt(df_sc_over1000$share_self_cite) # square root
df_sc_over1000$inv_share_self_cite <- 1/df_sc_over1000$share_self_cite # inverse
df_sc_over1000$sqrtinv_share_self_cite <- sqrt(df_sc_over1000$share_self_cite) # square root + inverse (sqrtinv)

# Compute the analysis of variance for each dataframe
self.aov <- aov(data = df_sc_over1000, share_self_cite ~ publisher)
self.aov.natlog <- aov(data = df_sc_over1000, natlog_share_self_cite ~ publisher)
self.aov.log10 <- aov(data = df_sc_over1000, log10_share_self_cite ~ publisher)
self.aov.sqrt <- aov(data = df_sc_over1000, log10_share_self_cite ~ publisher)
self.aov.inv <- aov(data = df_sc_over1000, inv_share_self_cite ~ publisher)
self.aov.sqrtinv <- aov(data = df_sc_over1000, sqrtinv_share_self_cite ~ publisher)

# Summaries of the analyses
summary(self.aov)
summary(self.aov.natlog)
summary(self.aov.log10)
summary(self.aov.sqrt)
summary(self.aov.inv)
summary(self.aov.sqrtinv)

# QQplots per dataframe, currently covered by # to run final script quicker.

# plot(self.aov, 1, cex=0.2)
# plot(self.aov, 2,cex=0.2) # raw data do not show a normal distribution
# 
# plot(self.aov.natlog, 1, cex=0.2)
# plot(self.aov.natlog, 2,cex=0.2) # natural log
# 
# plot(self.aov.log10, 1, cex=0.2)
# plot(self.aov.log10, 2,cex=0.2) # log10
# 
# plot(self.aov.sqrt, 1, cex=0.2)
# plot(self.aov.sqrt, 2,cex=0.2) # square root
# 
# plot(self.aov.inv, 1, cex=0.2)
# plot(self.aov.inv, 2,cex=0.2) # inverse
# 
# plot(self.aov.sqrtinv, 1, cex=0.2)
# plot(self.aov.sqrtinv, 2,cex=0.2) # square root + inverse (qualitatively most normal distribution)


## Tukey's Honest Significant Difference multiple test corrections of the analyses

# Multiple comparisons for all data transformations for the interested reader
# The square root + inverse transformation was taken for the final Fig5B

TK<-TukeyHSD(self.aov)
TK
TK_data<-as.data.frame(TK[1]) # the [1] locates the part of the output to be exported
write.csv(TK_data, 'Tables/self-cite2021_rawdata_TukeyHSD.csv')
TK <- emmeans(self.aov, "publisher")
# Generate letter-based grouping for multiple comparisons
letter_groups <- cld(TK, Letters = letters)
letter_groups
write.csv(letter_groups, 'Tables/self-cite2021_rawdata_TukeyHSD.csv')

TK<-TukeyHSD(self.aov.sqrtinv) # most normal version
TK
TK_data<-as.data.frame(TK[1]) # the [1] locates the part of the output to be exported
write.csv(TK_data, 'Tables/self-cite2021_sqrtinv_TukeyHSD.csv')
TK <- emmeans(self.aov.sqrtinv, "publisher")
# Generate letter-based grouping for multiple comparisons
letter_groups <- cld(TK, Letters = letters)
letter_groups
write.csv(letter_groups, 'Tables/self-cite2021_sqrtinv_TukeyHSD_lettergroups.csv')

## add letter groups to plot

# Merge the letter_groups and meaninf data
merged_data_sc <- merge(letter_groups, df_sc, by = "publisher")
head(merged_data_sc)

merged_data_sc <- merged_data_sc %>%
  filter(year == 2021) %>%
  filter(publisher %in% subset_publishers) %>%
  group_by(year, publisher) %>%
  mutate(meaninf = mean(inflation, na.rm = TRUE))
merged_data_sc <- merged_data_sc %>%
  mutate(.group = trimws(.group))

merged_data_sc<- merged_data_sc %>% 
  filter(year == 2021) %>% 
  mutate(share_self_cite = share_self_cite) %>%
  filter(publisher %in% subset_publishers) %>%
  filter(total_cites > 1000) %>%
  group_by(publisher) 


# plot Fig5supp6

# self_cite_2021<-ggplot(merged_data_sc, aes(share_self_cite, reorder(publisher,share_self_cite)))+
#   geom_jitter(aes(fill = publisher), height = 0.4, width = 0, size = 2,
#               alpha = 0.1, shape = 21, color = "grey50")+
#   geom_violin(alpha = 0.1, adjust = 1.5)+
#   geom_boxplot(width=0.1, alpha = 0.1)+
#   geom_text(aes(x = 0.25, label = merged_data_sc$.group), 
#             hjust = 0, size = 4, color = "blue") +  
#   scale_fill_manual(values = sapply(df$publisher, get_publisher_color)) +
#   xlim(0, 0.25) + 
#   theme(legend.position = "none")+
#   labs(title = "Within-journal self citation rate, 2021", 
#        subtitle = "Does not include journals citing across each other", 
#        y = "",
#        x = "proportion self-citation", 
#        caption = "Only shows journals with total annual citations > 1000
#        the x axis is cut off at 0.25 to prevent the plot from stretching due to a few major outliers
#        Source: Scimago scrape data")
# self_cite_2021
# ggsave(plot = self_cite_2021, "Figures/supplemental/Fig5_supp6_2021_selfcite_scrapedata.png", 
#        height = 12/1.2, width = 12/1.2, units = "in", dpi = 300)

example_self_cite_2021<-ggplot(merged_data_sc, aes(share_self_cite, reorder(publisher,share_self_cite)))+
  geom_jitter(aes(fill = publisher), height = 0.4, width = 0, size = 2,
              alpha = 0.1, shape = 21, color = "grey50")+
  geom_violin(alpha = 0.1, adjust = 1.5)+
  geom_boxplot(width=0.1, alpha = 0.1)+
  geom_text(aes(x = 0.25, label = merged_data_sc$.group), 
            hjust = 0, size = 4, color = "blue") +  
  scale_fill_manual(values = sapply(df$publisher, get_publisher_color)) +
  theme(legend.position = "none")+
  labs(title = "Within-journal self citation rate, 2021", 
       subtitle = "Does not include journals citing across each other", 
       y = "",
       x = "proportion self-citation", 
       caption = "Only shows journals with total annual citations > 1000, and the x axis is cut off at 0.25 to prevent the plot from stretching due to a few major outliers
       Source: Scimago scrape data")
example_self_cite_2021
ggsave(plot = example_self_cite_2021, "Figures/supplemental/Fig5_supp6_2021_selfcite_scrapedata.png", 
       height = 12/1.2, width = 12/1.2, units = "in", dpi = 300)


############################################
## STATISTICS self citation data 2022
############################################

# Filter dataset for only journals with >1000 citations per year, for 2021 specifically as per Fig5A
# Also removed zero values to enable data transformations and test for robustness to extent of data normality
# Journals with zeros/NAs in SJR are removed as infinites and highly unique cases (not indexed in Scimago that year)
# Journals with zeros/NAs in IF are also removed as being highly unique cases (no citations per year, but receives SJR anyways)
# Only >1000 citations per year added as a filter because data aggregated at journal level,
## meaning young journals without many papers to cite can reduce the apparent self-citation rate at the publisher level,
## or niche journals with high rates of self-cite can inflate it instead (but in an academically-justifiable way)

df_sc_over1000<-df_sc %>%
  filter(total_cites > 1000,
         year == 2022,
         share_self_cite>0,
         publisher %in% subset_publishers)

# creating multiple dataframes to test effect of different transformations as data do not have a normal distribution

df_sc_over1000$natlog_share_self_cite <- log(df_sc_over1000$share_self_cite,) # natural log
df_sc_over1000$log10_share_self_cite <- log(df_sc_over1000$share_self_cite,base=10) # log10
df_sc_over1000$sqrt_share_self_cite <- sqrt(df_sc_over1000$share_self_cite) # square root
df_sc_over1000$inv_share_self_cite <- 1/df_sc_over1000$share_self_cite # inverse
df_sc_over1000$sqrtinv_share_self_cite <- sqrt(df_sc_over1000$share_self_cite) # square root + inverse (sqrtinv)

# Compute the analysis of variance for each dataframe

self.aov <- aov(data = df_sc_over1000, share_self_cite ~ publisher)
self.aov.natlog <- aov(data = df_sc_over1000, natlog_share_self_cite ~ publisher)
self.aov.log10 <- aov(data = df_sc_over1000, log10_share_self_cite ~ publisher)
self.aov.sqrt <- aov(data = df_sc_over1000, log10_share_self_cite ~ publisher)
self.aov.inv <- aov(data = df_sc_over1000, inv_share_self_cite ~ publisher)
self.aov.sqrtinv <- aov(data = df_sc_over1000, sqrtinv_share_self_cite ~ publisher)

# Summaries of the analyses
summary(self.aov)
summary(self.aov.natlog)
summary(self.aov.log10)
summary(self.aov.sqrt)
summary(self.aov.inv)
summary(self.aov.sqrtinv)

# QQplots per dataframe, currently covered by # to run final script quicker.
## The code for these is provided for the interested reader, but blocked by # to prevent
## unnecessarily generating multiple plots with thousands of data points in succession (slow).
## Both square root and inverse transformations provide the closest approximation of normality,
## assessed by visualizing QQ plots and residuals. All data transformations agree in trends,
## except that sqrtinv is unique in finding no significant difference between Taylor & Francis and MDPI
## when all other data structures found this comparison to be statistically significant (P < .05)

# plot(self.aov, 1, cex=0.2)
# plot(self.aov, 2,cex=0.2) # raw data do not show a normal distribution
# 
# plot(self.aov.natlog, 1, cex=0.2)
# plot(self.aov.natlog, 2,cex=0.2) # natural log
# 
# plot(self.aov.log10, 1, cex=0.2)
# plot(self.aov.log10, 2,cex=0.2) # log10
# 
# plot(self.aov.sqrt, 1, cex=0.2)
# plot(self.aov.sqrt, 2,cex=0.2) # square root
# 
# plot(self.aov.inv, 1, cex=0.2)
# plot(self.aov.inv, 2,cex=0.2) # inverse
# 
# plot(self.aov.sqrtinv, 1, cex=0.2)
# plot(self.aov.sqrtinv, 2,cex=0.2) # square root + inverse (qualitatively most normal distribution)


## Tukey's Honest Significant Difference multiple test corrections of the analyses

#Multiple comparisons (all comparisons)

TK<-TukeyHSD(self.aov)
TK
TK_data<-as.data.frame(TK[1]) 
write.csv(TK_data, 'Tables/self-cite2022_rawdata_TukeyHSD.csv')
TK <- emmeans(self.aov, "publisher")
# Generate letter-based grouping for multiple comparisons
letter_groups <- cld(TK, Letters = letters)
letter_groups
write.csv(letter_groups, 'Tables/self-cite2022_rawdata_TukeyHSD.csv')


TK<-TukeyHSD(self.aov.sqrtinv) # most normal version
TK
TK_data<-as.data.frame(TK[1]) 
write.csv(TK_data, 'Tables/self-cite2022_sqrtinv_TukeyHSD.csv')
TK <- emmeans(self.aov.sqrtinv, "publisher")
# Generate letter-based grouping for multiple comparisons
letter_groups <- cld(TK, Letters = letters)
letter_groups
write.csv(letter_groups, 'Tables/self-cite2022_sqrtinv_TukeyHSD_lettergroups.csv')

## add letter groups to plot

# Merge the letter_groups and meaninf data
merged_data_sc <- merge(letter_groups, df_sc, by = "publisher")
head(merged_data_sc)

# Assuming merged_data_sc contains the merged letter_groups and meaninf data
merged_data_sc <- merged_data_sc %>%
  filter(year == 2022) %>%
  filter(publisher %in% subset_publishers) %>%
  group_by(year, publisher) %>%
  mutate(meaninf = mean(inflation, na.rm = TRUE))
merged_data_sc <- merged_data_sc %>%
  mutate(.group = trimws(.group))

merged_data_sc<- merged_data_sc %>% 
  filter(year == 2022) %>% 
  mutate(share_self_cite = share_self_cite) %>%
  filter(publisher %in% subset_publishers) %>%
  filter(total_cites > 1000) %>%
  group_by(publisher) 
self_cite_2022<-ggplot(merged_data_sc, aes(share_self_cite, reorder(publisher,share_self_cite)))+
  geom_jitter(aes(fill = publisher), height = 0.4, width = 0, size = 2,
              alpha = 0.1, shape = 21, color = "grey50")+
  geom_violin(alpha = 0.1, adjust = 1.5)+
  geom_boxplot(width=0.1, alpha = 0.1)+
  geom_text(aes(x = 0.24, label = merged_data_sc$.group), 
            hjust = 0, vjust = 0, size = 6, color = "blue") + 
  scale_fill_manual(values = sapply(df$publisher, get_publisher_color)) +
  xlim(0, 0.25) + 
  theme(
    axis.title.y.left = element_text(color = "black", size = 24),
    axis.text.y.left = element_text(color = "black", margin = margin(r = 3, l = +30), size = 18),
    axis.text.x = element_text(color = "black", margin = margin(r = 3), size = 18, vjust = 2),
    axis.title.x = element_text(color = "black", margin = margin(r = 3, l = +30), size = 18),
    legend.position = "none",
  )+
  labs(y = "",
       x = "Proportion self-citation", 
       caption = "Journals with total annual citations > 1000
       The x axis is limited at 0.25 to prevent the plot from stretching to show just a few major outliers
       Source: Scimago scrape data")
self_cite_2022
Fig5B<-self_cite_2022
ggsave(plot = self_cite_2022, "Figures/Building blocks/Fig5b_2022_selfcite_scrapedata.png", 
       height = 12/1.2, width = 12/1.2, units = "in", dpi = 300)

# # an alternate Fig5 layout that is horizontal
# Figure4 <- (Fig5A + Fig5B)
# Figure4 + plot_annotation(tag_levels = 'A') &
#   theme(plot.tag = element_text(size = 36))
# ggsave("Figures/Fig5_patchwork.png", 
#        width = 22, height = 9, units = "in", dpi = 300)

# patchwork vertical
Figure5 <- (Fig5A / Fig5B)
Figure5 + plot_annotation(tag_levels = 'A') &
  theme(plot.tag = element_text(size = 36))
ggsave("Figures/Figure_5.png", 
       width = 13.5, height = 18, units = "in", dpi = 300)
