###
### The Strain on Scientific Publishing - Fig1_N_papers_per_journal_per_publisher.R
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description:
### produces Fig 1C -- "rise of mega journals" -- mean N of articles per journal at major publishers
###
###

#### 1. data: reusing data from end of last script #####

journal_growth_data <- dfplot %>%
  group_by(publisher, year, journal) %>%
  summarise(N = sum(Ndocs)) %>%
  group_by(publisher, year) %>%
  summarise(TotalArticles = sum(N),
            UniqueJournals = n()) %>%
  mutate(ArticlesPerJournal = TotalArticles / UniqueJournals,
         ArticlesPerJournal = round(ArticlesPerJournal))


#### 2. plot: Fig 1C ####

Fig1C <- journal_growth_data %>%
  ggplot(aes(year, ArticlesPerJournal, color = publisher)) +
  geom_line(linewidth = 1.3) +
  scale_y_continuous(labels = scales::label_number(scale_cut = cut_short_scale())) +
  gghighlight::gghighlight(publisher %in% c("Hindawi","MDPI", 
                                            "Elsevier", "Frontiers", 
                                            "Springer", "PLOS", "Nature",
                                            "Wiley", "Taylor & Francis",  "BMC"),
                           label_params = list(direction = "y", nudge_x = 4, hjust = 1, size = 8), 
                           use_group_by = F, label_key = publisher) +
  scale_x_continuous(breaks = seq(2013, 2022, by = 3)) +
  #scale_color_brewer(palette = "Set1")+
  scale_color_manual(values = publisher_color_mapping) +
  theme(
    axis.title.y.left = element_text(color = "black", size = 24),
    axis.text.y.left = element_text(color = "black", margin = margin(r = 3, l = +30), size = 18),
    axis.text.x = element_text(color = "black", margin = margin(r = 3), size = 18), 
    panel.grid.major.x = element_blank()
  )+
  labs(#subtitle = "Fig1C: Total articles per unique journal per publisher",
       y = "Mean annual articles per journal",
       x = "",
       caption = "Source: Scimago website data")

## saving
ggsave("Figures/Building blocks/Fig1C_N_papers_per_journal_per_publisher.png",Fig1C,
       height = 9 / 1.1, width = 14/ 1.1, units = "in", dpi = 300)

## cleaning up
rm(journal_growth_data)