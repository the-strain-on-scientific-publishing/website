###
### The Strain on Scientific Publishing - Fig1_supp_JournalGrowth.R
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description:
### Produces Fig 1 supp 2 and Fig 1 supp 3 
###
###
###


#### 1. Fig 1 supp 2 ####

# data
journal_growth_data <- dfplot %>%
  group_by(publisher, year, journal) %>%
  summarise(N = sum(Ndocs)) %>%
  distinct(publisher, year, journal) %>%
  group_by(publisher, year) %>%
  summarise(UniqueJournals = n())

# plot
journal_growth_plot <- journal_growth_data %>%
  ggplot(aes(year, UniqueJournals, color = publisher)) +
  geom_line(linewidth = 1.3) +
  scale_y_continuous(labels = scales::label_number(scale_cut = cut_short_scale())) +
  gghighlight::gghighlight(publisher %in% c("MDPI", "Elsevier", 
                                            "Frontiers", "Springer",
                                            "Hindawi", "PLOS", "BMC", "Nature",
                                            "Wiley", "Taylor & Francis"),
                           label_params = list(direction = "y", nudge_x = 2, hjust = 1), 
                           use_group_by = F, label_key = publisher) +
  scale_x_continuous(breaks = seq(2013, 2022, by = 3)) +
  scale_color_manual(values = publisher_color_mapping) +
  labs(title = "Total journals by publisher",
       y = "Total unique journals",
       x = "",
       caption = "Source: Scimago website data")+
  theme(panel.grid.major.x = element_blank(), 
        axis.title.x = element_text(size = 18),
        axis.title.y = element_text(size = 18),
        axis.text.x = element_text(size = 16),
        axis.text.y = element_text(size = 16))

## saving the plot
ggsave(plot = journal_growth_plot,
       "Figures/Supplemental/Fig1supp2.png",
       height = 9 / 1.2, width = 12 / 1.2, units = "in", dpi = 300)


#### 1. Fig 1 supp 3 ####

megajou <- df %>% 
  mutate(class = case_when(Ndocs <= 52 ~ "Small (<1 paper/week)",
                           Ndocs > 52 & Ndocs <= 365 ~ "Medium (<1 paper/day)",
                           Ndocs > 365 & Ndocs <= 3650 ~ "Large (<10 papers/day)",
                           Ndocs > 3650 ~ "Mega (>10 papers/day)")) %>% 
  mutate(publisher = as.factor(publisher), class = as.factor(class)) %>% 
  mutate(class = fct_relevel(class, "Small (<1 paper/week)", "Medium (<1 paper/day)", "Large (<10 papers/day)")) %>% 
  group_by(year, class, .drop = F) %>% 
  tally() %>% 
  #filter(class == "Mega (>10 papers/day)") %>% 
  filter(n != 0) %>% 
  filter(year >=2002) 

# computing the X change 2002/22
labels <- megajou %>% 
  ungroup() %>% 
  filter(year == min(year) | year == max(year)) %>% 
  pivot_wider(names_from = year, values_from = n) %>% 
  mutate(percchange = 100*(`2022` - `2002`)/`2002`) %>% 
  mutate(class2 = paste0(class, ": +", round(percchange), "%"))

megajou %>% 
  left_join(labels, by = join_by(class)) %>% 
  mutate(class2 = fct_relevel(class2, "Small (<1 paper/week): +34%", "Medium (<1 paper/day): +99%", "Large (<10 papers/day): +245%")) %>% 
  ggplot(aes(year, n, color = class))+
  geom_line(size = 1.3)+
  facet_wrap(~class2, scales = "free_y")+
  scale_x_continuous(breaks = seq(2002, 2022, 5))+
  theme(legend.position = "none", 
        panel.grid.major.x = element_blank())+
  theme(panel.grid.major.x = element_blank(), 
        axis.title.x = element_text(size = 18),
        axis.title.y = element_text(size = 18),
        axis.text.x = element_text(size = 16),
        axis.text.y = element_text(size = 16))+
  labs(title = "Number of journals by class of size, 2002-22", 
       y = "N journals",
       x = "",
       caption = "Source: Scimago website data")

# saving the figure

ggsave("Figures/Supplemental/Fig1supp3.png", 
       width = 16/1.2, height = 9/1.2, units = "in", dpi = 300) # width = 16/1.2 in order to avoid cutting off axis.text.x 2022

rm(megajou, labels, journal_growth_data)
