###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description:
### To reduce memory footprint & speed up R, delete objects that will not be needed from now on
###
###

## plots
rm(Fig5_supp5A, Fig5_supp5B, Fig5A, Fig5B, Fig5supp1A, Fig5supp1B, Figure5, Figure5_supp5, Figure5supp1)
rm(IF_Inflation_2021, IF_Inflation_2022, Inflation_2022)

## ancillary dfs
rm(df_filtered, df_IF, df_inf_size, df_sc, df_sc_over1000, dfplot, dfTK, CITESvsIF_plot)
rm(merged_data, merged_data_sc)
rm(letter_groups)

## model objects
rm(res.aov, res.aov.sqrtinv, self.aov, self.aov.inv, self.aov.log10, self.aov.natlog, self.aov.sqrt, self.aov.sqrtinv)
rm(TK, TK_data)

## various
rm(example_self_cite_2021, lm_df, self_cite_2022, size)


## clean memory
gc()
