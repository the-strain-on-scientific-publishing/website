###
### The Strain on Scientific Publishing - Fig1_N_papers_and_publishers.R
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
### Description:
### Main figure indicating increase in N papers over time

#### 1. getting the data and the corresponding ID to publisher table in ####

## source of this is SCIMAGO
df <- read_csv("Data/Scimago_data_filtered.csv") 
ID <- read_csv("Data/sjr_ID_to_publisher.csv") 

df <- df %>% 
  left_join(ID, by = join_by(journal, publisher))
rm(ID)

#### 2. Data cleaning ####

## First, assign different publisher names to the correct publisher

df <- clean_publisher_names(df)


#### 3. Plot the total number of PhDs and the total number of artcile published ####

## compute the total number of PhDs from OECD data

OECD_data <- read_csv("Data/N_PhDs_OECD_Totals.csv")

# subset OECD_data for only doctoral-level degrees
string_to_keep <- 'Doctoral' # remove Bachelor's / Master's degrees and keep only PhDs

OECD_data <- OECD_data %>%
  filter_all(any_vars(str_detect(., string_to_keep)))

string_to_remove <- 'Arts and humanities' # remove non-science PhDs

OECD_data <- OECD_data %>%
  filter(!str_detect(Field, string_to_remove))

# added in response to Frontiers letter
head(OECD_data)
OECD_2011 <- OECD_data[OECD_data$year == 2011 & OECD_data$Value > 0,]
OECD_2013 <- OECD_data[OECD_data$year == 2013 & OECD_data$Value > 0,]
OECD_2015 <- OECD_data[OECD_data$year == 2015 & OECD_data$Value > 0,]
OECD_2022 <- OECD_data[OECD_data$year == 2022 & OECD_data$Value > 0,]
unique_countries_2011 <- unique(OECD_2011$country)
unique_countries_2013 <- unique(OECD_2013$country)
unique_countries_2015 <- unique(OECD_2015$country)
unique_countries_2022 <- unique(OECD_2022$country)
OECD_2013_2015_diffs1 <- setdiff(unique_countries_2013, unique_countries_2011)
OECD_2013_2015_diffs1
OECD_2013_2015_diffs2 <- setdiff(unique_countries_2015, unique_countries_2013)
OECD_2013_2015_diffs2
OECD_2013_2015_diffs3 <- setdiff(unique_countries_2022, unique_countries_2015)
OECD_2013_2015_diffs3

TotalPhDs <- OECD_data %>% 
  mutate(year = as.numeric(year)) %>%
  mutate(value = as.numeric(Value)) %>%
  group_by(year) %>%
  summarise(PhDs = sum(value, na.rm = TRUE)) %>%
  ungroup()

## Total number of articles published
TotalArts <- df %>% 
  mutate(year = as.numeric(year)) %>% 
  group_by(year) %>% 
  summarise(N = sum(Ndocs)) %>% 
  ungroup()

# compute figure 2016-22 for abstract 
TotalArts %>% 
  filter(year %in% c(2016, 2022)) %>% 
  mutate(growth = 100*(N - lag(N))/lag(N))


combined_df <- left_join(TotalArts,TotalPhDs, by = "year")

## cleanup
rm(string_to_remove, string_to_keep)
  

#### 4. Plotting Fig1A ####

# facto to scale right-hand-side axis
scaleFactor <- (max(combined_df$N) / max(combined_df$PhDs,na.rm=T))*.8

# figure
Fig1A <- combined_df %>% 
  filter(year >= 2013 & year <= 2022) %>% 
  ggplot(aes(x = year)) +
    # N papers
    geom_line(aes(y = N), col = "black", linewidth = 1.5) +
    # N PhDs, scaled
    geom_line(aes(y = PhDs * scaleFactor), col = "red", na.rm = TRUE, linewidth = 1.5, linetype = "dashed")+
    scale_y_continuous(name = "Total articles (in millions)",
                       labels = millions_format,
                       sec.axis = sec_axis(~ . / scaleFactor, name = "PhDs awarded in OECD countries",labels = thousands_format),
                       limits = c(1700000, 2900000),
                       breaks = seq(1700000, 3000000, by = 400000)) +  # Set limits for the left y-axis
    scale_x_continuous(breaks = seq(2013, 2021, by = 3)) +
    theme(
      axis.title.y.left = element_text(color = "black", size = 24),
      axis.text.y.left = element_text(color = "black", margin = margin(r = 3, l = +30), size = 18, hjust=0),
      axis.text.x = element_text(color = "black", margin = margin(r = 3), size = 18),
      axis.title.y.right = element_text(color = "red", angle = 270, hjust = 0.2, vjust = 1.5, size = 24, margin = margin(r=3,l=+30)),
      axis.text.y.right = element_text(color = "red", size = 18),
      panel.grid.major = element_blank(),
      panel.grid.minor = element_blank(),
      axis.ticks.y.left = element_line(),
      axis.ticks.y.right = element_line(color="red")
    )+
    labs(#title = "Number of newly published papers and newly awarded PhD titles per year, 2013-22", 
         #subtitle = "Number of PhDs on the right scale",
         caption = "Source: N papers -- Scimago website data; N PhDs - OECD",
         x = '')

ggsave("Figures/Building blocks/Fig1A_N_Papers_PhDs.png", Fig1A,
       width = 12/1, height = 9/1, unit = "in", dpi = 300)

##sharing
sharing_Fig1A_raw <- combined_df %>% 
  filter(year >= 2013 & year <= 2022)

write.csv(sharing_Fig1A_raw,"data sharing/Fig1A_raw.csv",row.names = FALSE)

## cleanup
rm(scaleFactor)
