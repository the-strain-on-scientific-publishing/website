###
###
### July 2023
###
### All analyses of the "Publication strain" paper
###
### by Mark Hanson, Paolo Crosetto, Pablo Gomez Barreiro, Dan Brockington
###
###
### Increase in N papers and N PhDs in time
###
###
library(tidyverse) 
library(gt)
library(gtExtras)
library(scales)
library(hrbrthemes)
library(patchwork)
library(ggtext)
library(here)
library(ggplot2)
library(dplyr)
library(gridExtra)
library(cowplot)

#### 1. getting the data and the corresponding ID to publisher table in ####

## source of this is SCIMAGO
df <- read_csv("Data/Scimago_data_filtered.csv") 
ID <- read_csv("Data/sjr_ID_to_publisher.csv") 

df <- df %>% 
  left_join(ID, by = join_by(journal, publisher))

head(df)
names(df)

#### 2. Data cleaning ####

## First, assign different publisher names to the correct publisher

df <- df %>% 
  mutate(publisher = case_when(
    publisher== "Maik Nauka Publishing / Springer SBM"~ "Springer",
    publisher== "Springer Berlin"~ "Springer",
    publisher== "Springer Boston"~ "Springer",
    publisher== "Springer China"~ "Springer",
    publisher== "Springer Fachmedien Wiesbaden GmbH"~ "Springer",
    publisher== "Springer Gabler"~ "Springer",
    publisher== "Springer GmbH &amp, Co, Auslieferungs-Gesellschaf"~ "Springer",
    publisher== "Springer Healthcare"~ "Springer",
    publisher== "Springer Heidelberg"~ "Springer",
    publisher== "Springer India"~ "Springer",
    publisher== "Springer International Publishing AG"~ "Springer",
    publisher== "Springer Japan"~ "Springer",
    publisher== "Springer London"~ "Springer",
    publisher== "Springer Nature"~ "Springer",
    publisher== "Springer Nature Switzerland AG"~ "Springer",
    publisher== "Springer Netherlands"~ "Springer",
    publisher== "Springer New York"~ "Springer",
    publisher== "Springer Paris"~ "Springer",
    publisher== "Springer Publishing Company"~ "Springer",
    publisher== "Springer Science + Business Media"~ "Springer",
    publisher== "Springer Science and Business Media B.V."~ "Springer",
    publisher== "Springer Science and Business Media Deutschland GmbH"~ "Springer",
    publisher== "Springer Singapore"~ "Springer",
    publisher== "Springer US"~ "Springer",
    publisher== "Springer Verlag"~ "Springer",
    publisher== "Springer Vieweg"~ "Springer",
    publisher== "SpringerOpen"~ "Springer",
    publisher== "Springer-Verlag GmbH and Co. KG"~ "Springer",
    publisher== "Springer-Verlag Italia Srl"~ "Springer",
    publisher== "Springer-Verlag Wien"~ "Springer",
    publisher== "Elsevier Ltd."~ "Elsevier",
    publisher== "Elsevier"~ "Elsevier",
    publisher== "Elsevier Inc."~ "Elsevier",
    publisher== "Elsevier BV"~ "Elsevier",
    publisher== "Elsevier USA"~ "Elsevier",
    publisher== "Elsevier Masson s.r.l."~ "Elsevier",
    publisher== "Elsevier Ireland Ltd"~ "Elsevier",
    publisher== "Elsevier Science B.V."~ "Elsevier",
    publisher== "Elsevier Science"~ "Elsevier",
    publisher== "Elsevier Sp. z o.o."~ "Elsevier",
    publisher== "Elsevier GmbH"~ "Elsevier",
    publisher== "Elsevier Espana"~ "Elsevier",
    publisher== "Elsevier Editora Ltda"~ "Elsevier",
    publisher== "Elsevier Doyma"~ "Elsevier",
    publisher== "Elsevier Taiwan LLC"~ "Elsevier",
    publisher== "Elsevier (Singapore) Pte Ltd"~ "Elsevier",
    publisher== "Elsevier Espana S.L.U"~ "Elsevier",
    publisher== "Elsevier Australia"~ "Elsevier",
    publisher== "Elsevier Science &amp; Technology"~ "Elsevier",
    publisher== "Elsevier Saunders"~ "Elsevier",
    publisher== "Elsevier Scientific Publishers Ireland"~ "Elsevier",
    publisher== "John Wiley &amp, Sons Inc."~ "Wiley",
    publisher== "John Wiley &amp; Sons Inc."~ "Wiley",
    publisher== "John Wiley and Sons Inc."~ "Wiley",
    publisher== "John Wiley and Sons Ltd"~ "Wiley",
    publisher== "Wiley - VCH Verlag GmbH &amp, CO. KGaA"~ "Wiley",
    publisher== "Wiley Blackwell"~ "Wiley",
    publisher== "Wiley Subscription Services"~ "Wiley",
    publisher== "Wiley-Blackwell"~ "Wiley",
    publisher== "Wiley-Blackwell for the International Association for the Study of Obesity"~ "Wiley",
    publisher== "Wiley-Blackwell Publishing Ltd"~ "Wiley",
    publisher== "Wiley-Liss Inc."~ "Wiley",
    publisher== "Wiley-VCH Verlag"~ "Wiley",
    publisher== "Routledge, Taylor &amp; Francis Group"~ "Taylor and Francis",
    publisher== "Taylor & Francis"~ "Taylor and Francis",
    publisher== "Taylor and Francis AS"~ "Taylor and Francis",
    publisher== "Taylor and Francis Inc."~ "Taylor and Francis",
    publisher== "Taylor and Francis Ltd."~ "Taylor and Francis",
    publisher== "Institute of Electrical and Electronics Engineers Inc."~ "IEEE",
    publisher== "IEEE Advancing Technology for Humanity"~ "IEEE",
    publisher== "IEEE Canada"~ "IEEE",
    publisher== "IEEE Circuits and Systems Society"~ "IEEE",
    publisher== "IEEE Communications Society"~ "IEEE",
    publisher== "IEEE Computational Intelligence Society"~ "IEEE",
    publisher== "IEEE Computer Society"~ "IEEE",
    publisher== "IEEE Education Society"~ "IEEE",
    publisher== "IEEE Electron Devices Society"~ "IEEE",
    publisher== "IEEE Geosciene and Remote Sensing Society"~ "IEEE",
    publisher== "IEEE Systems, Man, and Cybernetics Society"~ "IEEE",
    publisher== "IGI Global Publishing"~ "IGI Global",
    publisher== "IGI Publishing"~ "IGI Global",
    publisher== "Multidisciplinary Digital Publishing Institute (MDPI)"~ "MDPI",
    publisher== "MDPI AG"~ "MDPI",
    publisher== "Hindawi Publishing Corporation"~ "Hindawi",
    publisher== "Hindawi Limited"~ "Hindawi",
    publisher== "Nature Partner Journals"~ "Nature",
    publisher== "Nature Publishing Group"~ "Nature",
    publisher== "Bentham Science Publishers"~ "Bentham Science",
    publisher== "Bentham Science Publishers B.V."~ "Bentham Science",
    publisher== "SAGE Publications Inc."~ "SAGE",
    publisher== "SAGE Publications Ltd"~ "SAGE",
    publisher== "Sage Publications"~ "SAGE",
    publisher== "Sage Publications India Pvt. Ltd"~ "SAGE",
    publisher== "Sage Periodicals Press"~ "SAGE",
    publisher== "SAGE-Hindawi Access to Research"~ "SAGE",
    publisher== "Walter de Gruyter GmbH"~ "De Gruyter",
    publisher== "De Gruyter Open Ltd."~ "De Gruyter",
    publisher== "De Gruyter Mouton"~ "De Gruyter",
    publisher== "de Gruyter"~ "De Gruyter",
    publisher== "Walter de Gruyter"~ "De Gruyter",
    publisher== "Walter de Gruyter GmbH &amp, Co. KG"~ "De Gruyter",
    publisher== "De Gruyter Oldenbourg"~ "De Gruyter",
    publisher== "Wolters Kluwer Medknow Publications"~ "Wolters Kluwer",
    publisher== "Wolters Kluwer Health"~ "Wolters Kluwer",
    publisher== "Wolters Kluwer (UK) Ltd."~ "Wolters Kluwer",
    publisher== "Lippincott Williams and Wilkins Ltd."~ "Lippincott",
    publisher== "Lippincott Williams and Wilkins"~ "Lippincott",
    publisher== "Rubber Division of the American Chemical Society"~ "American Chemical Society",
    publisher== "Brunner - Routledge (US)"~ "Routledge",
    publisher== "Institute of Physics Publishing"~ "IOP Publishing Ltd.",
    publisher == "Frontiers Media S.A." ~ "Frontiers",
    publisher == "BioMed Central Ltd." ~ "BMC", 
    publisher == "American Chemical Society" ~ "ACS", 
    publisher == "Association for Computing Machinery (ACM)" ~ "ACM", 
    publisher == "American Institute of Aeronautics and Astronautics Inc. (AIAA)" ~ "AIAA",
    publisher == "Oxford University Press" ~ "Oxford UP", 
    publisher == "Public Library of Science" ~ "PLOS",
    TRUE ~ publisher))

df <- df %>%
  mutate(publisher = str_replace(publisher, "Taylor and Francis", "Taylor & Francis"))


#### 3. Plot the total number of PhDs and the total number of artcile published

## compute the total number of PhDs from OECD data here (accessed July 23 2023): https://stats.oecd.org/Index.aspx?DataSetCode=EDU_GRAD_FIELD

OECD_data <- read_csv("Data/N_PhDs_OECD_Totals.csv")

# subset OECD_data for only doctoral-level degrees
string_to_keep <- 'Doctoral' # remove Bachelor's / Master's degrees and keep only PhDs
OECD_data <- OECD_data %>%
  filter_all(any_vars(str_detect(., string_to_keep)))
string_to_remove <- 'Arts and humanities' # remove non-science PhDs
OECD_data <- OECD_data %>%
  filter(!str_detect(Field, string_to_remove))

TotalPhDs <- OECD_data %>% 
  mutate(year = as.numeric(year)) %>%
  mutate(value = as.numeric(Value)) %>%
  group_by(year) %>%
  summarise(PhDs = sum(value, na.rm = TRUE)) %>%
  ungroup()

## Total number of articles published
Ndocuments <- df %>% 
  mutate(year = as.numeric(year)) %>% 
  group_by(year) %>% 
  summarise(Ndocs = sum(Ndocs)) %>% 
  ungroup()


combined_df <- left_join(Ndocuments,TotalPhDs, by = "year")

combined_df <- combined_df %>%
  filter(year >= 2013 & year <= 2022)

## NOTE: currently we only have PhDs up to 2020, but we have Ndocs up to 2022 (accessed July 23 2023)
combined_df

###
# OKAY, LET'S GET THESE STATISTICS
###

# OECD total PhDs change 2015-2020

as.integer(combined_df$year)
as.numeric(combined_df$PhDs)
change_phds <- combined_df$PhDs[combined_df$year=='2020']-combined_df$PhDs[combined_df$year=='2015'] # answer: 13589 added between 2015 and 2020
change_ndocs <- combined_df$Ndocs[combined_df$year=='2020']-combined_df$PhDs[combined_df$year=='2015']/combined_df$Ndocs[combined_df$year=='2015'] # answer: 589192 added between 2015 and 2020

ratio_2020 <- combined_df$Ndocs[combined_df$year=='2020']/combined_df$PhDs[combined_df$year=='2020'] # answer: 9.51932
ratio_2015 <- combined_df$Ndocs[combined_df$year=='2015']/combined_df$PhDs[combined_df$year=='2015'] # answer: 7.627451
ratio_2020/ratio_2015 # Ndocs/PhDs ratio went up by 1.248034 (~125%)

## what if we plot the ratio of Ndocs to PhD grads over time?

combined_df$ratio <- combined_df$Ndocs/combined_df$PhDs
combined_df

# figure (exploratory) - it would be interesting to project the total PhDs into 2022 to see how extreme this ratio gets as Ndocs have only increased
plot<- combined_df %>% 
  ggplot(aes(x = year)) +
  # N papers
  geom_line(aes(y = ratio), col = "black", size = 1.5, na.rm = TRUE) +
  scale_y_continuous(name = "Ndocs / PhDs")+
  scale_x_continuous(breaks = seq(2013, 2022, by = 2))+
  labs(title = "Ratio Ndocs to PhD graduates in OECD countries", 
       subtitle = "How has this ratio changed over time?",
       caption = "Source: N papers -- Scimago data direct download; N PhDs - OECD")
plot
ggsave(plot, "Figures/Fig1suppZZ_Ndocs_per_PhD.png", 
       width = 12/1, height = 9/1, unit = "in", dpi = 300)

##

change_ndocs_2017to2022 <- combined_df$Ndocs[combined_df$year=='2022']-combined_df$Ndocs[combined_df$year=='2017'] # answer: 822162 added between 2017 and 2022
change_ndocs_2017to2022 # answer: 822162
Ndocs_2022 <- combined_df$Ndocs[combined_df$year=='2022']
Ndocs_2022 # answer: 2816304
prop_new <- change_ndocs_2017to2022/Ndocs_2022 # answer: 0.2919294
prop_new # answer: 0.2919294

###
# CONCLUSION
###

## There are 822k more articles per year in 2022 compared to 2017
## This means 29.2% of articles per year in 2022 are 'added' since 2017
## Comparing total PhDs awarded to total articles added, there are 43.4X more articles per year per PhD graduate (to write, review, edit) in 2020 compared to 2015



###
# How many of those articles are being contributed per publisher?
###

head(df)

## A handy vector of the main publishers
main_publishers <- c("Cell Press",
                     "MDPI",
                     "Nature Group",
                     "Springer",
                     "ACS",
                     "Elsevier",
                     "Frontiers",
                     "Wiley",
                     "PLoS",
                     "Company of Biologists Ltd",
                     "BMC",
                     "Oxford UP",
                     "American Institute of Aeronautics and Astronautics Inc. (AIAA)",
                     "IGI Global",
                     "American Astronomical Society",
                     "Association for Computing Machinery (ACM)",
                     "American Physical Society",
                     "Bentham Science",
                     "The Royal Society",
                     "IEEE",
                     "Hindawi",
                     "SAGE",
                     "Wolters Kluwer",
                     "De Gruyter",
                     "Lippincott",
                     "IOP Publishing Ltd.",
                     "Routledge",
                     "Taylor and Francis",
                     "The Royal Society",
                     "IOP Publishing Ltd.")

## restrict attention to the main publishers only

df2 <- df %>%
  group_by(publisher, year) %>%
  summarise(Total_Ndocs = sum(Ndocs))

# Step 3: Filter the data for the years 2017 and 2022
df3 <- df2 %>%
  filter(year %in% c(2017, 2022), publisher %in% c(main_publishers))

df3_rownum<-nrow(df3)

print(df3, n = df3_rownum)

# growth in MDPI articles 2017 to 2022
mdpi_total_2022 <- df3$Total_Ndocs[df3$publisher == "MDPI" & df3$year == 2022]
mdpi_total_2017 <- df3$Total_Ndocs[df3$publisher == "MDPI" & df3$year == 2017]
mdpi_difference <- mdpi_total_2022 - mdpi_total_2017
mdpi_difference # answer: 229240
mdpi_difference/change_ndocs_2017to2022 # answer: 0.2788258

# growth in Elsevier articles 2017 to 2022
Elsevier_total_2022 <- df3$Total_Ndocs[df3$publisher == "Elsevier" & df3$year == 2022]
Elsevier_total_2017 <- df3$Total_Ndocs[df3$publisher == "Elsevier" & df3$year == 2017]
Elsevier_difference <- Elsevier_total_2022 - Elsevier_total_2017
Elsevier_difference # answer: 129130
Elsevier_difference/change_ndocs_2017to2022 # answer: 0.1570615

# growth in Frontiers articles 2017 to 2022
Frontiers_total_2022 <- df3$Total_Ndocs[df3$publisher == "Frontiers" & df3$year == 2022]
Frontiers_total_2017 <- df3$Total_Ndocs[df3$publisher == "Frontiers" & df3$year == 2017]
Frontiers_difference <- Frontiers_total_2022 - Frontiers_total_2017
Frontiers_difference # answer: 93546
Frontiers_difference/change_ndocs_2017to2022 # answer: 0.1137805

# growth in Springer articles 2017 to 2022
Springer_total_2022 <- df3$Total_Ndocs[df3$publisher == "Springer" & df3$year == 2022]
Springer_total_2017 <- df3$Total_Ndocs[df3$publisher == "Springer" & df3$year == 2017]
Springer_difference <- Springer_total_2022 - Springer_total_2017
Springer_difference # answer: 79575
Springer_difference/change_ndocs_2017to2022 # answer: 0.09678749

# growth in Wiley-Blackwell articles 2017 to 2022
Wiley_total_2022 <- df3$Total_Ndocs[df3$publisher == "Wiley" & df3$year == 2022]
Wiley_total_2017 <- df3$Total_Ndocs[df3$publisher == "Wiley" & df3$year == 2017]
Wiley_difference <- Wiley_total_2022 - Wiley_total_2017
Wiley_difference # answer: 44614
Wiley_difference/change_ndocs_2017to2022 # answer: 0.05426424

# growth in Taylor and Francis articles 2017 to 2022
Taylor_and_Francis_total_2022 <- df3$Total_Ndocs[df3$publisher == "Taylor and Francis" & df3$year == 2022]
Taylor_and_Francis_total_2017 <- df3$Total_Ndocs[df3$publisher == "Taylor and Francis" & df3$year == 2017]
Taylor_and_Francis_difference <- Taylor_and_Francis_total_2022 - Taylor_and_Francis_total_2017
Taylor_and_Francis_difference # answer: 37086
Taylor_and_Francis_difference/change_ndocs_2017to2022 # answer: 0.0451079

# growth in SAGE articles 2017 to 2022
SAGE_total_2022 <- df3$Total_Ndocs[df3$publisher == "SAGE" & df3$year == 2022]
SAGE_total_2017 <- df3$Total_Ndocs[df3$publisher == "SAGE" & df3$year == 2017]
SAGE_difference <- SAGE_total_2022 - SAGE_total_2017
SAGE_difference # answer: 28245
SAGE_difference/change_ndocs_2017to2022 # answer: 0.03435454

# growth in Hindawi articles 2017 to 2022
Hindawi_total_2022 <- df3$Total_Ndocs[df3$publisher == "Hindawi" & df3$year == 2022]
Hindawi_total_2017 <- df3$Total_Ndocs[df3$publisher == "Hindawi" & df3$year == 2017]
Hindawi_difference <- Hindawi_total_2022 - Hindawi_total_2017
Hindawi_difference # answer: 24867
Hindawi_difference/change_ndocs_2017to2022 # answer: 0.03024586

# growth in IEEE articles 2017 to 2022
IEEE_total_2022 <- df3$Total_Ndocs[df3$publisher == "IEEE" & df3$year == 2022]
IEEE_total_2017 <- df3$Total_Ndocs[df3$publisher == "IEEE" & df3$year == 2017]
IEEE_difference <- IEEE_total_2022 - IEEE_total_2017
IEEE_difference # answer: 38509
IEEE_difference/change_ndocs_2017to2022 # answer: 0.0468387

# growth in ACS articles 2017 to 2022
ACS_total_2022 <- df3$Total_Ndocs[df3$publisher == "ACS" & df3$year == 2022]
ACS_total_2017 <- df3$Total_Ndocs[df3$publisher == "ACS" & df3$year == 2017]
ACS_difference <- ACS_total_2022 - ACS_total_2017
ACS_difference # answer: 15530
ACS_difference/change_ndocs_2017to2022 # answer: 0.01888922



## The top five publishers in terms of adding strain are MDPI, Elsevier, Frontiers, Springer, and Wiley

mdpi_difference # answer: 229240
Elsevier_difference # answer: 129130
Frontiers_difference # answer: 93546
Springer_difference # answer: 79575
Wiley_difference # answer: 44614

strain_cont_top5 <- sum(mdpi_difference,Elsevier_difference,Frontiers_difference,Springer_difference,Wiley_difference)/change_ndocs_2017to2022 # answer: 0.7007196
strain_cont_top5 # answer: 0.7007196

## % of journals owned by Springer and Elsevier together in 2022

EandS<-df%>%
  filter(year==2022)%>%
  filter(publisher=="Elsevier"|publisher=="Springer")%>%
  distinct()
all_2022<-df%>%filter(year==2022)%>%distinct()

percent<-nrow(EandS)/(nrow(all_2022))
