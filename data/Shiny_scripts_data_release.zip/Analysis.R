###
### The Strain on Scientific Publishing - Analysis.R
###
###
### by Mark Hanson, Pablo Gómez Barreiro, Paolo Crosetto & Dan Brockington
###
###
### Description: 
### This script assembles the scimago data if you download it separately
### You will need to download all Scimago data from at least 2002-2022 to
### run everything successfully, but otherwise downloading just 2013-2022 is sufficient for most figures
### Check the "Figures/Building blocks" folder for the Fig. 5A panel
### We had to web-scrape Scimago to obtain self-cite data systematically, so we cannot
### share this unfortunately. But we encourage users to visit scimagojr.com, which already
### has a fantastic web interface for their data, including dynamic plots and journal comparisons.
### 

#### 0. Libraries ####

source("Scripts/0_Packages_Install_Load.R")


#### 0. Settings ####

source("Scripts/0_initial_settings.R")


#### 0. helper functions ####

source("Scripts/helper_functions.R")


#### 0. assemble Scimago annual .csv files into single dataframe ####

# Raw Scimago .csv files can be downloaded from: https://www.scimagojr.com/journalrank.php
# These should be saved to a folder within Data called "raw_data_Scimago" to enable the script below to run without tinkering

# source("Scripts/0_Merge_raw_Scimago_data.R")


#####################################################################################################
# FROM HERE ON, DIFFERENT SCRIPTS CARRY OUT THE ANALYSES
# 
# WITHIN A PART, THEY ARE INTENDED TO RUN _IN THIS VERY ORDER_
#
# THEY WILL LIKELY NOT WORK IF RUN IN A CUSTOM ORDER, AS SOME OBJECTS DEPEND ON PREVIOUS SCRIPTS
#####################################################################################################

#### Part 1. N papers, N papers per journal, N phd students ####

# Figure 1A
source("Scripts/Fig1_calcs_strain_numbers_by_publisher.R")
source("Scripts/Fig1_N_papers_and_PhDs.R")
source("Scripts/Fig1_N_papers_per_Publisher.R")
source("Scripts/Fig1_N_papers_per_journal_per_publisher.R")
source("Scripts/Fig1_magick.R")

# Figure 1 supp 1
source("Scripts/Fig1_supp_OECD.R")
source("Scripts/Fig1_supp_UNESCO.R")
source("Scripts/Fig1_supp_magick.R")

# Figure 1 supp 2 and supp 3
source("Scripts/Fig1_supp_JournalGrowth.R")

# Figure 5 supp 3: run here since it uses data treated here, even if it is later in the manuscript
source("Scripts/Fig5_supp3_Refs_per_doc.R") 

# cleaning up after Part 1
source("Scripts/cleanup_after_part_1.R")



#### Part 5. Impact Factor Inflation ####

## Figure 5A
source("Scripts/Fig5_Inflation.R")

## Figure 5 supp 1
source("Scripts/Fig5_supp1_change_IF_SJR.R")

## Figure 5 supp 2
source("Scripts/Fig5_supp2_Inflation_journal_size.R")

## Figure 5 supp 4
source("Scripts/Fig5_supp4A_IFvsCitPerDoc_2021.R") 
source("Scripts/Fig5_supp4B_IFvsCitPerDoc_2022.R") 
source("Scripts/Fig5supp4_magick.R") 


## cleanup after part 5
source("Scripts/cleanup_after_part_5.R")

### Run package grateful to cite R packages and create references

source("Scripts/Z_run_grateful.R")
